# NexBell Phase 2 - architecture preparation

**Status: NOT IMPLEMENTED.** Nothing below exists in the app yet. This file only records where each
feature would plug into the current architecture and what has to be built first.

## Current architecture (what Phase 2 builds on)
- UI: `public/NexBell.html` (unchanged) exposes `NexBell.setState()`, `NexBell.doorbell()` and retry hooks.
- `public/bridge.js`: Red5 WHEP video, 30 s polling of `POST /api/analyze`, diagnostics via `/health` and `/api/status`.
- Native: `NexBellApiPlugin` (adds the bearer token natively, allow-lists `/health` and `/api/*`), `NexBellApp` (OneSignal init), `MainActivity`.
- Backend: FastAPI at https://53ahzy.bot-keep.xyz (owned separately; not in this ZIP).

## Feature map
| Feature | Status | Where it plugs in | Needs first |
|---|---|---|---|
| Home / Away / Night modes | Not implemented | New `mode` value held by the backend and read via a new `GET/PUT /api/mode`; `bridge.js` adjusts poll rate and alert policy | Backend endpoints, UI control (needs a design decision: NexBell.html is frozen) |
| Person detection zones | Not implemented | Zone polygon (stored as 0-1 proportions) sent with or stored for `/api/analyze`; the UI already shows a "No Detection Zone" state and `onZone` hook | Real camera snapshot endpoint; zone editor UI; backend cropping/masking |
| Geofencing, adjustable radius | Not implemented | Native Android location + `GeofencingClient`, mode switch on enter/exit | `ACCESS_FINE_LOCATION` + background location permission, Play-services geofencing dependency, privacy review |
| Family backup phone notifications | Not implemented | OneSignal external user ids / segments per family member; backend sends to the backup phone if the primary does not acknowledge | Backend escalation timer, acknowledgement endpoint |
| Referral codes and family access | Not implemented | Backend auth: owner account, invite codes, per-member tokens (replaces the single shared token) | Backend user/auth model |
| Video-call-style alerts | Partly present | UI call screen exists (`#call`, `NexBell.doorbell()`); a locked-screen full-screen alert needs a native full-screen-intent notification | `USE_FULL_SCREEN_INTENT` handling, OneSignal notification extender |
| Godrej Secure Hub handoff | Not implemented | Deep link / intent into the Secure Hub app | No documented public Secure Hub API or intent was provided; do not assume one |
| Advanced notifications, surveillance history | Not implemented | Backend event store + `GET /api/events`; History/Visitors screens read it | Backend persistence; UI wiring |

## Security prerequisite for family access
Today there is one shared bearer token compiled into the APK. Extracting it from an APK is possible, so
before family access ships, move to per-user credentials issued by the backend and keep revocation there.
