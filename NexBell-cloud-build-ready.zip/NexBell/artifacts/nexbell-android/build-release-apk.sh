#!/usr/bin/env bash
# One-command release build. Needs: Node 20+, pnpm, JDK 21, Android SDK (platform 36, build-tools 36.0.0),
# and internet for the first run (npm + Gradle + Maven dependencies).
# Run from anywhere:  bash artifacts/nexbell-android/build-release-apk.sh
set -euo pipefail
APP="$(cd "$(dirname "$0")" && pwd)"
ROOT="$(cd "$APP/../.." && pwd)"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
[ -n "$ANDROID_HOME" ] || { echo "Set ANDROID_HOME to your Android SDK folder."; exit 1; }
echo "sdk.dir=$ANDROID_HOME" > "$APP/android/local.properties"
# Secrets: android/nexbell-secrets.properties OR env vars NEXBELL_API_TOKEN / ONESIGNAL_APP_ID (cloud CI).
if [ -z "${NEXBELL_API_TOKEN:-}" ]; then
  grep -qs '^NEXBELL_API_TOKEN=.\+' "$APP/android/nexbell-secrets.properties" || { echo "Set NEXBELL_API_TOKEN (env var or android/nexbell-secrets.properties)."; exit 1; }
fi
# Signing: keystore.properties, or env KEYSTORE_BASE64 + KEYSTORE_PASSWORD (+ optional KEY_ALIAS), else a new key is generated.
if [ ! -f "$APP/android/keystore.properties" ]; then
  if [ -n "${KEYSTORE_BASE64:-}" ] && [ -n "${KEYSTORE_PASSWORD:-}" ]; then
    echo "$KEYSTORE_BASE64" | base64 -d > "$APP/android/nexbell-release.jks"
    printf 'storeFile=nexbell-release.jks\nstorePassword=%s\nkeyAlias=%s\nkeyPassword=%s\n' "$KEYSTORE_PASSWORD" "${KEY_ALIAS:-nexbell}" "${KEY_PASSWORD:-$KEYSTORE_PASSWORD}" > "$APP/android/keystore.properties"
  else
    bash "$APP/android/make-keystore.sh"
  fi
fi
cd "$ROOT" && corepack enable >/dev/null 2>&1 || true; pnpm install --frozen-lockfile
cd "$APP" && pnpm run build:android:web && pnpm exec cap sync android
cd "$APP/android" && ./gradlew --no-daemon clean assembleRelease
APK="$APP/android/app/build/outputs/apk/release/app-release.apk"
[ -f "$APK" ] && echo "APK: $APK" && "$(ls -d "$ANDROID_HOME"/build-tools/*/ | sort -V | tail -1)apksigner" verify --verbose "$APK" | head -5
