// NexBell public connection settings.
// Only the backend origin lives here. The API token is never stored in web files:
// the Android app injects it natively (see android/nexbell-secrets.properties.example).
window.NEXBELL_CONFIG = {
  apiBaseUrl: 'https://53ahzy.bot-keep.xyz',
};
