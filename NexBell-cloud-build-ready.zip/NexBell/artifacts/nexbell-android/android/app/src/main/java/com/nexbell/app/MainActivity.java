package com.nexbell.app;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;
import com.onesignal.Continue;
import com.onesignal.OneSignal;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(NexBellApiPlugin.class);
        super.onCreate(savedInstanceState);
        if (BuildConfig.ONESIGNAL_APP_ID != null && !BuildConfig.ONESIGNAL_APP_ID.isEmpty()) {
            // Android 13+ shows the POST_NOTIFICATIONS prompt here.
            OneSignal.getNotifications().requestPermission(false, Continue.none());
        }
    }
}
