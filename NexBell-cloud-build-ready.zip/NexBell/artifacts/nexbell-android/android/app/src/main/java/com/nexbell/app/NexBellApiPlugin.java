package com.nexbell.app;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

/**
 * Native bridge to the NexBell FastAPI backend.
 *
 * The bearer token is compiled in from a build-time secret (BuildConfig) and added
 * here, so it never appears in any web asset. Only the backend host from
 * BuildConfig.BACKEND_URL can be reached, and only /health and /api/* paths.
 */
@CapacitorPlugin(name = "NexBellApi")
public class NexBellApiPlugin extends Plugin {
    private static final int MAX_BODY_BYTES = 1024 * 1024;

    @PluginMethod
    public void request(final PluginCall call) {
        final String path = call.getString("path", "");
        final String method = call.getString("method", "GET").toUpperCase();
        final String body = call.getString("body", "");

        if (path == null || !(path.equals("health") || path.startsWith("api/")) || path.contains("..") || path.contains("://")) {
            call.reject("Path not allowed");
            return;
        }
        if (!(method.equals("GET") || method.equals("POST"))) {
            call.reject("Method not allowed");
            return;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                HttpURLConnection conn = null;
                try {
                    String base = BuildConfig.BACKEND_URL.replaceAll("/+$", "");
                    URL url = new URL(base + "/" + path);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod(method);
                    conn.setConnectTimeout(15000);
                    conn.setReadTimeout(60000);
                    conn.setRequestProperty("Accept", "application/json");
                    if (BuildConfig.NEXBELL_API_TOKEN != null && !BuildConfig.NEXBELL_API_TOKEN.isEmpty()) {
                        conn.setRequestProperty("Authorization", "Bearer " + BuildConfig.NEXBELL_API_TOKEN);
                    }
                    if (method.equals("POST")) {
                        conn.setDoOutput(true);
                        conn.setRequestProperty("Content-Type", "application/json");
                        byte[] payload = (body == null || body.isEmpty() ? "{}" : body).getBytes(StandardCharsets.UTF_8);
                        OutputStream os = conn.getOutputStream();
                        os.write(payload);
                        os.close();
                    }
                    int status = conn.getResponseCode();
                    InputStream is = status >= 400 ? conn.getErrorStream() : conn.getInputStream();
                    String text = "";
                    if (is != null) {
                        ByteArrayOutputStream bos = new ByteArrayOutputStream();
                        byte[] buf = new byte[4096];
                        int n;
                        while ((n = is.read(buf)) != -1 && bos.size() < MAX_BODY_BYTES) {
                            bos.write(buf, 0, n);
                        }
                        is.close();
                        text = bos.toString("UTF-8");
                    }
                    JSObject out = new JSObject();
                    out.put("status", status);
                    out.put("body", text);
                    String ct = conn.getContentType();
                    out.put("contentType", ct == null ? "" : ct);
                    call.resolve(out);
                } catch (Exception e) {
                    call.reject("Network error: " + e.getClass().getSimpleName());
                } finally {
                    if (conn != null) conn.disconnect();
                }
            }
        }).start();
    }
}
