package com.nexbell.app;

import android.app.Application;

import com.onesignal.OneSignal;
import com.onesignal.debug.LogLevel;

public class NexBellApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        // The OneSignal App ID is a build-time value (nexbell-secrets.properties).
        // If it is empty, push is simply not initialised; nothing is faked.
        if (BuildConfig.ONESIGNAL_APP_ID != null && !BuildConfig.ONESIGNAL_APP_ID.isEmpty()) {
            OneSignal.getDebug().setLogLevel(LogLevel.NONE);
            OneSignal.initWithContext(this, BuildConfig.ONESIGNAL_APP_ID);
        }
    }
}
