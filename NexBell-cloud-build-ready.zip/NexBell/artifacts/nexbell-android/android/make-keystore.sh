#!/usr/bin/env bash
# Creates a release signing key and keystore.properties. Run once, then BACK UP both files:
# losing the key means you cannot update an installed NexBell APK (you would have to uninstall first).
set -euo pipefail
cd "$(dirname "$0")"
[ -f nexbell-release.jks ] && { echo "nexbell-release.jks already exists - not overwriting."; exit 1; }
PASS="$(LC_ALL=C tr -dc 'A-Za-z0-9' </dev/urandom | head -c 24)"
keytool -genkeypair -v -keystore nexbell-release.jks -alias nexbell -keyalg RSA -keysize 2048 \
  -validity 10000 -storepass "$PASS" -keypass "$PASS" -dname "CN=NexBell, O=NexBell, C=IN"
printf 'storeFile=nexbell-release.jks\nstorePassword=%s\nkeyAlias=nexbell\nkeyPassword=%s\n' "$PASS" "$PASS" > keystore.properties
chmod 600 keystore.properties nexbell-release.jks
echo "Created nexbell-release.jks and keystore.properties (both git-ignored). Back them up."
