# NexBell build report

## Result
- **Release APK: NOT built.** The environment used for this work had no Android SDK, no Gradle
  distribution/cache and no network access, so Gradle could not run. No APK is included, and none
  was faked or mocked.
- The project is prepared so a single command produces a signed, directly installable APK on a machine
  with the SDK (see "Build it").

## What changed
1. **Secret handling:** the API token was sitting in `public/nexbell-config.js` (a public web file). It is removed
   from every web asset (public, dist, android assets). The Android app now sends API calls through a native
   plugin (`NexBellApiPlugin`) that adds the `Authorization` header from a build-time secret. The plugin only
   reaches the configured backend host and only `/health` and `/api/*`. The token is still inside the APK
   (extractable by a determined person); it is just no longer in plain web files.
2. **Backend wiring:** `bridge.js` keeps the existing `/health`, `/api/status` and `POST /api/analyze` flow and
   the existing HUMAN + `should_notify` mapping. Backend URL: https://53ahzy.bot-keep.xyz.
3. **OneSignal:** SDK dependency `com.onesignal:OneSignal` 5.1.x, initialised in `NexBellApp` when `ONESIGNAL_APP_ID` is set;
   notification permission requested at launch (Android 13+). Without an App ID, push is simply off.
4. **Manifest:** added `ACCESS_NETWORK_STATE`, `POST_NOTIFICATIONS`; cleartext traffic off; `allowBackup` off.
   No CAMERA or microphone permission: the app plays the camera's Red5 stream and does not use the phone camera.
5. **Gradle:** BuildConfig fields, release signing config read from `keystore.properties`, larger Gradle heap.
6. **Signing:** `android/make-keystore.sh` creates a release keystore; `build-release-apk.sh` runs the full build.
7. `NexBell.html` is untouched.

## Not verified (could not run here)
- Gradle build, Java compilation against Capacitor/OneSignal (only a syntax check passed), signing, install on a phone.
- OneSignal delivery: needs your App ID and the backend to send pushes to this app's subscriptions.
- Live video, AI detection and notifications on a device.

## Build it
```
cd artifacts/nexbell-android/android
cp nexbell-secrets.properties.example nexbell-secrets.properties   # fill NEXBELL_API_TOKEN, ONESIGNAL_APP_ID
cd .. && export ANDROID_HOME=/path/to/android-sdk                  # platform 36, build-tools 36.0.0
bash build-release-apk.sh
```
Output: `android/app/build/outputs/apk/release/app-release.apk`. Back up `nexbell-release.jks` and `keystore.properties`.

## Things you should know
- **Rotate the API token.** It was inside the ZIP you uploaded, so treat it as exposed.
- `NexBell.html` already contains demo controls ("Show demo data", state previews, "Zone saved (demo)"). Your
  rules say both "don't touch NexBell.html" and "no demo controls"; I kept the file untouched. Tell me if you
  want them removed.
- `bridge.js` loads the Red5 SDK from jsDelivr (`@latest`) and the WebRTC adapter from GitHub Pages at runtime.
  Unpinned remote scripts; pin versions once you have confirmed a working one.
- `source/` still holds old Supabase and Express code from earlier iterations. It is not used by the app build.
- Phase 2: see `PHASE2-ARCHITECTURE.md`. None of it is implemented.

## Cloud build (CI)
Requirements: Node 20+, pnpm 9 or 10 (lockfile v9), JDK 21, Android SDK platform 36 + build-tools 36.0.0, internet.
Env vars: `ANDROID_HOME`, `NEXBELL_API_TOKEN`, optional `ONESIGNAL_APP_ID`; signing via `KEYSTORE_BASE64` + `KEYSTORE_PASSWORD`
(+ optional `KEY_ALIAS`, `KEY_PASSWORD`). Without them a new throwaway key is generated, which cannot update an installed app.
Run: `bash artifacts/nexbell-android/build-release-apk.sh`.
