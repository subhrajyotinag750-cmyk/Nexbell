import { App } from '@capacitor/app';
import { Browser } from '@capacitor/browser';
import { Capacitor } from '@capacitor/core';

declare global {
  interface Window {
    go?: (screen: string) => void;
    ring?: (active: number) => void;
  }
}

if (Capacitor.isNativePlatform()) {
  void App.addListener('backButton', () => {
    const callScreen = document.getElementById('call');
    if (callScreen?.classList.contains('on')) {
      window.ring?.(0);
      return;
    }

    const activeScreen = document.querySelector<HTMLElement>('.scr.on');
    if (activeScreen?.id === 'trouble-s') {
      window.go?.('settings');
      return;
    }
    if (activeScreen?.id && activeScreen.id !== 'home-s') {
      window.go?.('home');
      return;
    }

    void App.exitApp();
  });

  document.addEventListener(
    'click',
    (event) => {
      const target = event.target;
      if (!(target instanceof Element)) return;

      const link = target.closest<HTMLAnchorElement>('a[href]');
      if (!link || link.hasAttribute('download')) return;

      let url: URL;
      try {
        url = new URL(link.href);
      } catch {
        return;
      }

      if (
        (url.protocol !== 'https:' && url.protocol !== 'http:') ||
        url.origin === window.location.origin
      ) {
        return;
      }

      event.preventDefault();
      void Browser.open({ url: url.href });
    },
    true,
  );
}
