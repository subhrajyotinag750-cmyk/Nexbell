# NexBell Android package

The Android app loads the supplied NexBell HTML locally from the APK. The approved
screen markup and styling are copied unchanged to `public/NexBell.html` and
`backups/NexBell.html.baseline`. The root `index.html` is the original project entry
with only native/config bootstrap scripts added.

## Backend URL

Set `apiBaseUrl` in `public/nexbell-config.js` before building:

- Supabase Edge Function root: `https://<project>.supabase.co/functions/v1/nexbell-api/`
- Existing Express API root: `https://<deployed-host>/api/`

Leave it blank to retain the existing Supabase endpoint from the bridge. The APK
does not contain NVIDIA or Sarvam provider credentials; those must remain configured
on the backend. Do not put private server keys in the app config.

## Android debug APK

Requirements: Node.js 20+, pnpm, JDK 21, Android SDK Platform 36, and Android
Build Tools 36 with the SDK licenses accepted.

From the workspace root:

```sh
pnpm install
cd artifacts/nexbell-android
pnpm run android:debug
```

The Capacitor Android project is already included. If starting from a copy that
does not contain `android/`, run `pnpm exec cap add android` once before building.

The debug APK is written to:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

To install on a connected device with USB debugging enabled, run:

```sh
cd android
./gradlew installDebug
```

For a release APK, create and protect a signing keystore, configure Gradle signing
properties outside source control, and build with `./gradlew assembleRelease`.
