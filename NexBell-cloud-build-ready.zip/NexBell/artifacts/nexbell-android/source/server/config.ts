import dotenv from 'dotenv';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

const __dirname = dirname(fileURLToPath(import.meta.url));
dotenv.config({ path: resolve(__dirname, '..', '.env') });

function required(name: string): string {
  const val = process.env[name];
  if (!val) throw new Error(`Missing required env var: ${name}`);
  return val;
}

function optional(name: string, fallback: string): string {
  return process.env[name] ?? fallback;
}

function intVar(name: string, fallback: number): number {
  const raw = process.env[name];
  if (!raw) return fallback;
  const n = parseInt(raw, 10);
  return Number.isNaN(n) ? fallback : n;
}

export const config = {
  port: intVar('PORT', 3001),
  nodeEnv: optional('NODE_ENV', 'development'),
  supabaseUrl: optional('VITE_SUPABASE_URL', ''),
  supabaseAnonKey: optional('VITE_SUPABASE_ANON_KEY', ''),
  red5Host: optional('RED5_HOST', 'userId-3321-e4b2f25a57.cloud.red5.net'),
  red5Stream: optional('RED5_STREAM', 'NexBell'),
  red5App: optional('RED5_APP', 'live'),
  cameraModel: optional('CAMERA_MODEL', 'GODSB06'),
  rateLimitWindowMs: intVar('RATE_LIMIT_WINDOW_MS', 60_000),
  rateLimitMax: intVar('RATE_LIMIT_MAX', 60),
  isProduction: optional('NODE_ENV', 'development') === 'production',
  nvidiaApiKey: optional('NVIDIA_API_KEY', ''),
  nvidiaVlmModel: optional('NVIDIA_VLM_MODEL', 'meta/llama-3.2-11b-vision-instruct'),
  nvidiaApiBase: optional('NVIDIA_API_BASE', 'https://integrate.api.nvidia.com/v1'),
  sarvamApiKey: optional('SARVAM_API_KEY', ''),
  sarvamVlmModel: optional('SARVAM_VLM_MODEL', 'gemma4'),
  sarvamApiBase: optional('SARVAM_API_BASE', 'https://api.sarvam.ai/v2'),
};

export function validateConfig(): { valid: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!config.supabaseUrl) missing.push('VITE_SUPABASE_URL');
  if (!config.supabaseAnonKey) missing.push('VITE_SUPABASE_ANON_KEY');
  return { valid: missing.length === 0, missing };
}
