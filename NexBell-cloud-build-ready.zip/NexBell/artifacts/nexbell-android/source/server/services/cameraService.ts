import { config } from '../config.js';

export interface CameraStatus {
  state: 'online' | 'offline' | 'unknown' | 'connecting';
  checkedAt: string;
  note: string;
  streamState?: string;
  edgeServer?: string;
  durationMs?: number;
}

/**
 * Camera service — probes the Red5 Pro Stream Manager 2.0 API to determine
 * whether the NexBell stream is actually live.
 *
 * Primary probe: GET /as/v1/streams/stream/<nodeGroup>/subscribe/<app>/<stream>
 * The stream GUID must include the app prefix (e.g. "live/NexBell", not "NexBell").
 *
 * Fallback probe: GET /as/v1/streams/stream/<nodeGroup> (lists all streams)
 *
 * Response interpretation:
 *  - 200 with state:"LIVE" → camera online
 *  - 200 with state:"AVAILABLE" → stream exists but not actively publishing
 *  - 404 → stream not found / not live
 *  - Network error → unknown
 */

class CameraServiceImpl {
  async getStatus(): Promise<CameraStatus> {
    return this.probe();
  }

  private async probe(): Promise<CameraStatus> {
    const checkedAt = new Date().toISOString();
    const host = config.red5Host;
    const nodeGroup = 'Baselin-9deA';
    const streamGuid = `${config.red5App}/${config.red5Stream}`;
    const url = `https://${host}/as/v1/streams/stream/${nodeGroup}/subscribe/${streamGuid}`;

    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);

      const res = await fetch(url, {
        signal: controller.signal,
        headers: { Accept: 'application/json' },
      });
      clearTimeout(timeout);

      if (res.ok) {
        const body = await res.json().catch(() => null);
        const streams = Array.isArray(body) ? body : body ? [body] : [];
        const live = streams.find(
          (s: { state?: string }) => s.state === 'LIVE'
        );

        if (live) {
          return {
            state: 'online',
            checkedAt,
            streamState: 'LIVE',
            note: 'Camera stream is live on Red5 Pro Stream Manager.',
            edgeServer: live.serverAddress,
            durationMs: live.durationMs,
          };
        }

        const available = streams.find(
          (s: { state?: string }) => s.state === 'AVAILABLE'
        );
        if (available) {
          return {
            state: 'offline',
            checkedAt,
            streamState: 'AVAILABLE',
            note: 'Stream exists but is not actively publishing media.',
          };
        }

        return {
          state: 'offline',
          checkedAt,
          streamState: streams[0]?.state || 'UNKNOWN',
          note: 'Stream responded but no LIVE or AVAILABLE state found.',
        };
      }

      if (res.status === 404) {
        const body = await res.json().catch(() => ({}));
        const msg = body.error || 'Stream not found on any node';
        return {
          state: 'offline',
          checkedAt,
          streamState: 'NOT_LIVE',
          note: `Camera stream is not currently published. Red5 reports: "${msg}"`,
        };
      }

      return {
        state: 'unknown',
        checkedAt,
        note: `Unexpected response from Stream Manager: HTTP ${res.status}`,
      };
    } catch (err) {
      const isAbort = err instanceof DOMException && err.name === 'AbortError';
      return {
        state: 'unknown',
        checkedAt,
        note: isAbort
          ? 'Probe timed out (5s). Camera status unknown.'
          : `Probe failed: ${(err as Error).message}`,
      };
    }
  }
}

export const cameraService = new CameraServiceImpl();
