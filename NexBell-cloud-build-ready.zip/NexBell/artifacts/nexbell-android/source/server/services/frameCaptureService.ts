import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { readFile, unlink } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';

const execFileAsync = promisify(execFile);

let ffmpegPath: string | null = null;
async function getFfmpegPath(): Promise<string> {
  if (ffmpegPath) return ffmpegPath;
  ffmpegPath = require('ffmpeg-static') as string;
  return ffmpegPath;
}

export interface CapturedFrame {
  data: Buffer;
  format: 'jpeg';
  width: number;
  height: number;
  capturedAt: string;
  sourceUrl: string;
}

/**
 * Frame capture service — extracts single JPEG frames from the live RTMP
 * stream on the Red5 media node. Uses ffmpeg-static (bundled binary, no
 * system dependency).
 *
 * The RTMP URL is constructed from the Stream Manager's publish endpoint
 * which returns the origin server address. Each capture connects, grabs
 * one frame, and disconnects — minimizing bandwidth on the camera's 4G SIM.
 */
export class FrameCaptureService {
  /**
   * Capture a single JPEG frame from the live stream.
   * Throws if the stream is unreachable or ffmpeg fails.
   */
  async captureFrame(rtmpUrl: string): Promise<CapturedFrame> {
    const ffmpeg = await getFfmpegPath();
    const tmpFile = join(tmpdir(), `nexbell_frame_${randomUUID()}.jpg`);

    try {
      const { stderr } = await execFileAsync(
        ffmpeg,
        [
          '-y',
          '-i', rtmpUrl,
          '-frames:v', '1',
          '-update', '1',
          '-f', 'image2',
          tmpFile,
        ],
        { timeout: 15_000, maxBuffer: 1024 * 1024 }
      );

      const data = await readFile(tmpFile);

      // Parse dimensions from stderr
      const dimMatch = stderr.match(/(\d+)x(\d+)/);
      const width = dimMatch ? parseInt(dimMatch[1], 10) : 0;
      const height = dimMatch ? parseInt(dimMatch[2], 10) : 0;

      if (data.length === 0) {
        throw new Error('Frame capture produced an empty file');
      }

      return {
        data,
        format: 'jpeg',
        width,
        height,
        capturedAt: new Date().toISOString(),
        sourceUrl: rtmpUrl,
      };
    } finally {
      await unlink(tmpFile).catch(() => {});
    }
  }
}

export const frameCaptureService = new FrameCaptureService();
