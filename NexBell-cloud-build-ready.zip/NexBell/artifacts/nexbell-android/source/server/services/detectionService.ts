import { config } from '../config.js';
import { frameCaptureService } from './frameCaptureService.js';
import { cameraService } from './cameraService.js';

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface DetectionResult {
  personDetected: boolean;
  confidence: 'high' | 'medium' | 'low' | 'unknown';
  confidenceReason: string;
  description: string;
  boundingBoxes: BoundingBox[];
  model: string;
  endpoint: string;
  provider: 'nvidia' | 'sarvam' | 'none';
  capturedAt: string;
  frameSize: number;
  sourceImageUrl: string;
  rawResponse: unknown;
  error?: string;
}

interface ChatCompletionResponse {
  id?: string;
  choices?: Array<{
    message?: { content?: string };
    finish_reason?: string;
  }>;
  usage?: { total_tokens?: number };
}

interface VlmProvider {
  name: 'nvidia' | 'sarvam';
  model: string;
  endpoint: string;
  apiKey: string;
}

const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
const REQUEST_TIMEOUT_MS = 30_000;
const DETECTION_PROMPT =
  'Analyze this image from a doorbell security camera. Answer in JSON format with these fields: ' +
  '"person_detected" (true/false), "confidence" (high/medium/low), "description" (brief description of what you see), ' +
  '"person_count" (number of people visible, 0 if none), "bounding_boxes" (array of {x, y, width, height} in pixels ' +
  'if person detected, empty array if not). Only output the JSON, no other text.';

/**
 * Person-detection service — captures a genuine JPEG frame from the live
 * RTMP stream and sends it to a hosted VLM for analysis.
 *
 * Tries NVIDIA first; on failure (no key, HTTP error, timeout) falls back
 * to Sarvam. Both use the OpenAI-compatible chat/completions format with
 * inline base64 image input.
 */
export class DetectionService {
  private getProviders(): VlmProvider[] {
    const providers: VlmProvider[] = [];
    if (config.nvidiaApiKey) {
      providers.push({
        name: 'nvidia',
        model: config.nvidiaVlmModel,
        endpoint: `${config.nvidiaApiBase}/chat/completions`,
        apiKey: config.nvidiaApiKey,
      });
    }
    if (config.sarvamApiKey) {
      providers.push({
        name: 'sarvam',
        model: config.sarvamVlmModel,
        endpoint: `${config.sarvamApiBase}/chat/completions`,
        apiKey: config.sarvamApiKey,
      });
    }
    return providers;
  }

  async detectFromLiveStream(): Promise<DetectionResult> {
    const providers = this.getProviders();
    if (providers.length === 0) {
      return this.noKeyResult();
    }

    const status = await cameraService.getStatus();
    if (status.state !== 'online' || !status.edgeServer) {
      return {
        personDetected: false,
        confidence: 'unknown',
        confidenceReason: 'Camera stream is not live',
        description: '',
        boundingBoxes: [],
        model: providers[0].model,
        endpoint: providers[0].endpoint,
        provider: 'none',
        capturedAt: new Date().toISOString(),
        frameSize: 0,
        sourceImageUrl: '',
        rawResponse: null,
        error: 'STREAM_OFFLINE',
      };
    }

    const rtmpUrl = `rtmp://${status.edgeServer}:1935/${config.red5App}/${config.red5Stream}`;
    const frame = await frameCaptureService.captureFrame(rtmpUrl);

    if (frame.data.length > MAX_IMAGE_BYTES) {
      throw new Error(
        `Frame too large: ${frame.data.length} bytes (max ${MAX_IMAGE_BYTES})`
      );
    }

    return this.detectFromFrame(frame.data, rtmpUrl);
  }

  async detectFromFrame(
    jpegData: Buffer,
    sourceUrl: string
  ): Promise<DetectionResult> {
    const providers = this.getProviders();
    if (providers.length === 0) {
      return this.noKeyResult();
    }

    const base64 = jpegData.toString('base64');
    const dataUrl = `data:image/jpeg;base64,${base64}`;

    let lastError: DetectionResult | null = null;

    for (const provider of providers) {
      const result = await this.callProvider(provider, dataUrl, jpegData.length, sourceUrl);

      if (!result.error) {
        return result;
      }

      lastError = result;
    }

    return lastError ?? this.noKeyResult();
  }

  private async callProvider(
    provider: VlmProvider,
    dataUrl: string,
    frameSize: number,
    sourceUrl: string
  ): Promise<DetectionResult> {
    const body = {
      model: provider.model,
      messages: [
        {
          role: 'user',
          content: [
            {
              type: 'image_url',
              image_url: { url: dataUrl },
            },
            {
              type: 'text',
              text: DETECTION_PROMPT,
            },
          ],
        },
      ],
      max_tokens: 512,
      temperature: 0.2,
      top_p: 1,
      stream: false,
    };

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    try {
      const res = await fetch(provider.endpoint, {
        method: 'POST',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${provider.apiKey}`,
        },
        body: JSON.stringify(body),
      });
      clearTimeout(timeout);

      const rawJson = await res.json().catch(() => null);

      if (!res.ok) {
        return {
          personDetected: false,
          confidence: 'unknown',
          confidenceReason: `${provider.name} API returned HTTP ${res.status}`,
          description: '',
          boundingBoxes: [],
          model: provider.model,
          endpoint: provider.endpoint,
          provider: provider.name,
          capturedAt: new Date().toISOString(),
          frameSize,
          sourceImageUrl: sourceUrl,
          rawResponse: rawJson,
          error: `${provider.name.toUpperCase()}_API_ERROR_${res.status}`,
        };
      }

      return this.parseVlmResponse(
        rawJson as ChatCompletionResponse,
        provider,
        frameSize,
        sourceUrl
      );
    } catch (err) {
      clearTimeout(timeout);
      const isAbort = err instanceof DOMException && err.name === 'AbortError';
      return {
        personDetected: false,
        confidence: 'unknown',
        confidenceReason: isAbort
          ? `${provider.name} request timed out (${REQUEST_TIMEOUT_MS / 1000}s)`
          : `${provider.name} request failed`,
        description: '',
        boundingBoxes: [],
        model: provider.model,
        endpoint: provider.endpoint,
        provider: provider.name,
        capturedAt: new Date().toISOString(),
        frameSize,
        sourceImageUrl: sourceUrl,
        rawResponse: null,
        error: (err as Error).message,
      };
    }
  }

  private parseVlmResponse(
    raw: ChatCompletionResponse,
    provider: VlmProvider,
    frameSize: number,
    sourceUrl: string
  ): DetectionResult {
    const text = raw.choices?.[0]?.message?.content ?? '';
    const parsed = this.extractJson(text);

    const personDetected = parsed?.person_detected === true;
    const confidenceRaw = String(parsed?.confidence ?? '');
    const confidence = this.normalizeConfidence(confidenceRaw);
    const boundingBoxes = this.normalizeBoundingBoxes(parsed?.bounding_boxes);

    return {
      personDetected,
      confidence,
      confidenceReason: confidence
        ? `${provider.name} VLM reported ${confidence} confidence`
        : `${provider.name} VLM did not report confidence level`,
      description: String(parsed?.description ?? text.substring(0, 200)),
      boundingBoxes,
      model: provider.model,
      endpoint: provider.endpoint,
      provider: provider.name,
      capturedAt: new Date().toISOString(),
      frameSize,
      sourceImageUrl: sourceUrl,
      rawResponse: raw,
    };
  }

  private extractJson(text: string): Record<string, unknown> | null {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return null;
    try {
      return JSON.parse(jsonMatch[0]);
    } catch {
      return null;
    }
  }

  private normalizeConfidence(raw: string): DetectionResult['confidence'] {
    const lower = raw.toLowerCase();
    if (lower === 'high') return 'high';
    if (lower === 'medium') return 'medium';
    if (lower === 'low') return 'low';
    return 'unknown';
  }

  private normalizeBoundingBoxes(raw: unknown): BoundingBox[] {
    if (!Array.isArray(raw)) return [];
    return raw
      .filter(
        (b) =>
          typeof b === 'object' &&
          b !== null &&
          typeof b.x === 'number' &&
          typeof b.y === 'number'
      )
      .map((b) => ({
        x: b.x,
        y: b.y,
        width: typeof b.width === 'number' ? b.width : 0,
        height: typeof b.height === 'number' ? b.height : 0,
      }));
  }

  private noKeyResult(): DetectionResult {
    return {
      personDetected: false,
      confidence: 'unknown',
      confidenceReason: 'No AI provider API key configured',
      description: '',
      boundingBoxes: [],
      model: config.nvidiaVlmModel,
      endpoint: config.nvidiaApiBase,
      provider: 'none',
      capturedAt: new Date().toISOString(),
      frameSize: 0,
      sourceImageUrl: '',
      rawResponse: null,
      error: 'AI_API_KEY_MISSING',
    };
  }
}

export const detectionService = new DetectionService();
