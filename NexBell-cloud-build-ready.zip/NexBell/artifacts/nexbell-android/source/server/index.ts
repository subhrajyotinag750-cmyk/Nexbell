import express from 'express';
import cors from 'cors';
import { config } from './config.js';
import { rateLimit } from './middleware/rateLimit.js';
import { notFound, errorHandler } from './middleware/errorHandler.js';
import healthRouter from './routes/health.js';
import cameraRouter from './routes/camera.js';

const app = express();

app.use(cors());
app.use(express.json({ limit: '1mb' }));

// Rate limit all API routes
app.use('/api', rateLimit(config.rateLimitWindowMs, config.rateLimitMax));

// Routes
app.use('/api', healthRouter);
app.use('/api/camera', cameraRouter);

// 404 + error handling (must be last)
app.use(notFound);
app.use(errorHandler);

function start(): void {
  app.listen(config.port, () => {
    console.log(`[NexBell] Backend listening on port ${config.port} (${config.nodeEnv})`);
  });
}

// Only auto-start when run directly, not when imported by tests
const isDirectRun =
  process.argv[1]?.endsWith('index.ts') ||
  process.argv[1]?.endsWith('index.js') ||
  process.argv[1]?.endsWith('server/index.ts');

if (isDirectRun) {
  start();
}

export { app };
