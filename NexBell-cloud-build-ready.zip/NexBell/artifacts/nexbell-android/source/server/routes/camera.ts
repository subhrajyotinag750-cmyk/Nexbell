import { Router } from 'express';
import { config } from '../config.js';
import { cameraService } from '../services/cameraService.js';
import { frameCaptureService } from '../services/frameCaptureService.js';
import { detectionService } from '../services/detectionService.js';

const router = Router();

/**
 * GET /api/camera/status — truthful camera status based on a real Red5
 * Stream Manager API probe. Status values: online | offline | unknown.
 */
router.get('/status', async (_req, res) => {
  const status = await cameraService.getStatus();
  res.status(200).json({
    status: status.state,
    streamState: status.streamState,
    model: config.cameraModel,
    stream: {
      host: config.red5Host,
      app: config.red5App,
      name: config.red5Stream,
    },
    edgeServer: status.edgeServer,
    durationMs: status.durationMs,
    lastChecked: status.checkedAt,
    note: status.note,
  });
});

/**
 * GET /api/camera/red5-info — Red5 configuration and frame-extraction
 * capabilities.
 */
router.get('/red5-info', (_req, res) => {
  res.status(200).json({
    playerUrl: `https://embed.red5.net/player.html?host=${config.red5Host}&node_group=Baselin-9deA&app=${config.red5App}&stream_name=${config.red5Stream}&api_version=v1&mode=sub`,
    streamManagerUrl: `https://${config.red5Host}`,
    host: config.red5Host,
    app: config.red5App,
    streamName: config.red5Stream,
    frameExtraction: {
      browser: 'blocked',
      reason: 'Red5 player is a cross-origin iframe; client-side frame extraction is impossible.',
      serverSide: 'available',
      method: 'RTMP frame capture via ffmpeg-static — backend connects to rtmp://<edgeServer>:1935/live/NexBell, grabs one frame, disconnects. Minimizes 4G data usage.',
    },
  });
});

/**
 * GET /api/camera/frame — captures and returns a single JPEG frame from the
 * live RTMP stream. Requires the stream to be LIVE.
 *
 * This endpoint connects to the RTMP stream, captures exactly one frame,
 * and immediately disconnects. Each capture uses minimal bandwidth (~40KB
 * for one 800x448 JPEG).
 */
router.get('/frame', async (_req, res) => {
  const status = await cameraService.getStatus();

  if (status.state !== 'online' || !status.edgeServer) {
    res.status(503).json({
      error: 'STREAM_OFFLINE',
      message: 'Camera stream is not live. Cannot capture frame.',
      streamState: status.streamState,
    });
    return;
  }

  const rtmpUrl = `rtmp://${status.edgeServer}:1935/${config.red5App}/${config.red5Stream}`;

  try {
    const frame = await frameCaptureService.captureFrame(rtmpUrl);
    res.setHeader('Content-Type', 'image/jpeg');
    res.setHeader('Content-Length', String(frame.data.length));
    res.setHeader('X-Frame-Source', rtmpUrl);
    res.setHeader('X-Frame-Captured-At', frame.capturedAt);
    res.setHeader('X-Frame-Dimensions', `${frame.width}x${frame.height}`);
    res.status(200).send(frame.data);
  } catch (err) {
    res.status(502).json({
      error: 'FRAME_CAPTURE_FAILED',
      message: 'Failed to capture frame from RTMP stream.',
      detail: (err as Error).message,
    });
  }
});

/**
 * GET /api/camera/detect — captures a genuine frame from the live stream
 * and runs person detection using a hosted VLM. Tries NVIDIA first, falls
 * back to Sarvam on failure.
 *
 * Returns a structured result: personDetected, confidence, bounding boxes,
 * provider, model used, and the raw VLM response. Requires at least one
 * provider API key.
 *
 * If no API key is configured, returns error "AI_API_KEY_MISSING" with
 * HTTP 503 so the caller knows exactly what's missing.
 */
router.get('/detect', async (_req, res) => {
  try {
    const result = await detectionService.detectFromLiveStream();

    if (result.error === 'AI_API_KEY_MISSING') {
      res.status(503).json(result);
      return;
    }
    if (result.error === 'STREAM_OFFLINE') {
      res.status(503).json(result);
      return;
    }

    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({
      error: 'DETECTION_FAILED',
      message: 'Person detection failed.',
      detail: (err as Error).message,
    });
  }
});

export default router;
