import { Router } from 'express';
import { config, validateConfig } from '../config.js';

const router = Router();

/**
 * GET /api/healthz — process liveness probe.
 * Returns 200 as long as the process is running and can accept requests.
 * Does NOT check external dependencies.
 */
router.get('/healthz', (_req, res) => {
  res.status(200).json({ status: 'ALIVE', uptime: process.uptime() });
});

/**
 * GET /api/health — health check consumed by NexBell.html runChecks().
 * Contract: must return HTTP 200 with JSON { status: 'ONLINE' } when healthy.
 * "Healthy" means: process alive AND required configuration present.
 * Camera connectivity is NOT checked here — backend health is independent
 * from camera health.
 */
router.get('/health', (_req, res) => {
  const cfg = validateConfig();
  if (!cfg.valid) {
    res.status(503).json({
      status: 'OFFLINE',
      error: 'CONFIG_INCOMPLETE',
      missing: cfg.missing,
    });
    return;
  }

  res.status(200).json({
    status: 'ONLINE',
    timestamp: new Date().toISOString(),
    version: '0.1.0',
  });
});

/**
 * GET /api/health/details — richer diagnostic info (not consumed by the HTML).
 */
router.get('/health/details', (_req, res) => {
  const cfg = validateConfig();
  res.status(200).json({
    status: cfg.valid ? 'ONLINE' : 'OFFLINE',
    config: {
      supabaseConfigured: !!config.supabaseUrl,
      red5Host: config.red5Host,
      red5Stream: config.red5Stream,
      cameraModel: config.cameraModel,
    },
    uptime: process.uptime(),
    env: config.nodeEnv,
  });
});

export default router;
