import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import supertest from 'supertest';
import { app } from '../index.js';

const request = supertest(app);

describe('GET /api/healthz', () => {
  it('returns 200 with ALIVE status', async () => {
    const res = await request.get('/api/healthz');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ALIVE');
    expect(typeof res.body.uptime).toBe('number');
  });
});

describe('GET /api/health', () => {
  it('returns 200 with ONLINE when config is present', async () => {
    const res = await request.get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ONLINE');
  });

  it('returns the exact status string the HTML expects', async () => {
    const res = await request.get('/api/health');
    // NexBell.html runChecks() checks: j.status === 'ONLINE'
    expect(res.body).toHaveProperty('status', 'ONLINE');
  });
});

describe('GET /api/health/details', () => {
  it('returns detailed diagnostic info', async () => {
    const res = await request.get('/api/health/details');
    expect(res.status).toBe(200);
    expect(res.body).toHaveProperty('config');
    expect(res.body.config).toHaveProperty('red5Host');
  });
});

describe('GET /api/camera/status', () => {
  it('returns truthful status based on real Red5 probe', async () => {
    const res = await request.get('/api/camera/status');
    expect(res.status).toBe(200);
    expect(['online', 'offline', 'unknown', 'connecting']).toContain(res.body.status);
    expect(res.body).toHaveProperty('model');
    expect(res.body).toHaveProperty('note');
    expect(res.body).toHaveProperty('streamState');
  });

  it('reports online when stream is LIVE on Red5', async () => {
    const res = await request.get('/api/camera/status');
    // The NexBell stream is currently published from Larix → Red5
    if (res.body.streamState === 'LIVE') {
      expect(res.body.status).toBe('online');
      expect(res.body.edgeServer).toBeDefined();
    }
  });

  it('includes stream config info', async () => {
    const res = await request.get('/api/camera/status');
    expect(res.body.stream).toHaveProperty('host');
    expect(res.body.stream).toHaveProperty('name', 'NexBell');
  });
});

describe('GET /api/camera/red5-info', () => {
  it('returns the Red5 player URL and frame-extraction limitation', async () => {
    const res = await request.get('/api/camera/red5-info');
    expect(res.status).toBe(200);
    expect(res.body.playerUrl).toContain('embed.red5.net');
    expect(res.body.frameExtraction.browser).toBe('blocked');
    expect(res.body.frameExtraction.serverSide).toBe('available');
  });
});

describe('GET /api/camera/frame', () => {
  it('captures a real JPEG frame when stream is live', async () => {
    const statusRes = await request.get('/api/camera/status');
    if (statusRes.body.status !== 'online') {
      // Stream not live — skip frame test gracefully
      console.log('Stream not live, skipping frame capture test');
      return;
    }
    const res = await request.get('/api/camera/frame');
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toBe('image/jpeg');
    expect(res.body.length).toBeGreaterThan(1000);
  }, 20_000);
});

describe('GET /api/camera/detect', () => {
  const hasAiKey = !!(process.env.NVIDIA_API_KEY || process.env.SARVAM_API_KEY);

  it('returns 503 with AI_API_KEY_MISSING when no provider key is set', async () => {
    const res = await request.get('/api/camera/detect');
    if (!hasAiKey) {
      expect(res.status).toBe(503);
      expect(res.body.error).toBe('AI_API_KEY_MISSING');
    } else {
      // If a key IS set, the endpoint should attempt real detection
      expect([200, 503]).toContain(res.status);
      expect(res.body).toHaveProperty('personDetected');
      expect(res.body).toHaveProperty('confidence');
      expect(res.body).toHaveProperty('model');
      expect(res.body).toHaveProperty('boundingBoxes');
      expect(['nvidia', 'sarvam', 'none']).toContain(res.body.provider);
    }
  }, 90_000);

  it('returns structured detection fields when a key is available and stream is live', async () => {
    if (!hasAiKey) {
      console.log('No AI provider key set, skipping live detection test');
      return;
    }
    const res = await request.get('/api/camera/detect');
    if (res.status === 200) {
      expect(res.body).toHaveProperty('personDetected');
      expect(typeof res.body.personDetected).toBe('boolean');
      expect(['high', 'medium', 'low', 'unknown']).toContain(res.body.confidence);
      expect(Array.isArray(res.body.boundingBoxes)).toBe(true);
      expect(res.body).toHaveProperty('model');
      expect(res.body).toHaveProperty('capturedAt');
      expect(res.body.frameSize).toBeGreaterThan(0);
      expect(['nvidia', 'sarvam']).toContain(res.body.provider);
    }
  }, 90_000);
});

describe('Error handling', () => {
  it('returns 404 for unknown routes', async () => {
    const res = await request.get('/api/nonexistent');
    expect(res.status).toBe(404);
    expect(res.body.error).toBe('NOT_FOUND');
  });
});
