import type { Request, Response, NextFunction } from 'express';

export interface AppError {
  status: number;
  error: string;
  message: string;
  details?: unknown;
}

export function notFound(_req: Request, res: Response): void {
  res.status(404).json({
    error: 'NOT_FOUND',
    message: 'The requested resource does not exist.',
  });
}

export function errorHandler(
  err: Error,
  _req: Request,
  res: Response,
  _next: NextFunction
): void {
  const status = (err as unknown as AppError).status ?? 500;
  const code = (err as unknown as AppError).error ?? 'INTERNAL_ERROR';

  // Never leak stack traces or internal error text in production
  const message =
    status >= 500
      ? 'An unexpected error occurred.'
      : err.message || 'Request failed.';

  res.status(status).json({ error: code, message });
}
