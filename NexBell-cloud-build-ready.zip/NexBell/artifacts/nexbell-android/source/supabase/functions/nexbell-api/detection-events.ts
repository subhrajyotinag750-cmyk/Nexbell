export type ConfidenceLevel = "high" | "medium" | "low" | "unknown";

export type DetectionUpdateType =
  | "none"
  | "visit_started"
  | "visit_active"
  | "visit_ended"
  | "cooldown_suppressed"
  | "unavailable";

export interface DetectionZone {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface VisitState {
  id: string;
  startedAt: string;
  lastSeenAt: string;
  confidence: ConfidenceLevel;
  personCount: number;
  observationCount: number;
}

export interface DetectionEvent {
  id: string;
  visitId: string;
  type: "visit_started" | "visit_ended";
  occurredAt: string;
  startedAt: string;
  lastSeenAt: string;
  endedAt?: string;
  confidence: ConfidenceLevel;
  personCount: number;
}

export interface DetectionObservation {
  valid: boolean;
  personPresent: boolean;
  confidence: ConfidenceLevel;
  personCount: number;
}

export interface DetectionUpdate {
  personDetected: boolean;
  personPresent: boolean;
  eventType: DetectionUpdateType;
  visitEvent: DetectionEvent | null;
  activeVisit: VisitState | null;
}

export interface DetectionEventOptions {
  minimumConfidence: ConfidenceLevel;
  visitGapMs: number;
  cooldownMs: number;
  maxEvents?: number;
}

const confidenceRank: Record<ConfidenceLevel, number> = {
  unknown: 0,
  low: 1,
  medium: 2,
  high: 3,
};

export function isConfidenceLevel(value: string): value is ConfidenceLevel {
  return value === "high" || value === "medium" || value === "low" || value === "unknown";
}

export function meetsConfidenceThreshold(
  confidence: ConfidenceLevel,
  minimum: ConfidenceLevel,
): boolean {
  return confidenceRank[confidence] >= confidenceRank[minimum] && confidence !== "unknown";
}

export function parseDetectionZone(raw: string | undefined): DetectionZone | null {
  if (!raw?.trim()) return null;

  let value: unknown;
  try {
    value = JSON.parse(raw);
  } catch {
    throw new Error("NEXBELL_DETECTION_ZONE must be valid JSON");
  }

  if (typeof value !== "object" || value === null) {
    throw new Error("NEXBELL_DETECTION_ZONE must be a JSON object");
  }

  const zone = value as Record<string, unknown>;
  const { x, y, width, height } = zone;
  if (
    typeof x !== "number" ||
    typeof y !== "number" ||
    typeof width !== "number" ||
    typeof height !== "number" ||
    ![x, y, width, height].every(Number.isFinite) ||
    x < 0 ||
    y < 0 ||
    width <= 0 ||
    height <= 0 ||
    x + width > 1 ||
    y + height > 1
  ) {
    throw new Error(
      "NEXBELL_DETECTION_ZONE requires normalized x, y, width, and height within 0..1",
    );
  }

  return { x, y, width, height };
}

export function isBoundingBoxInZone(
  box: BoundingBox,
  zone: DetectionZone,
  imageWidth: number,
  imageHeight: number,
): boolean {
  if (
    !Number.isFinite(imageWidth) ||
    !Number.isFinite(imageHeight) ||
    imageWidth <= 0 ||
    imageHeight <= 0 ||
    ![box.x, box.y, box.width, box.height].every(Number.isFinite) ||
    box.width <= 0 ||
    box.height <= 0
  ) {
    return false;
  }

  const centerX = (box.x + box.width / 2) / imageWidth;
  const centerY = (box.y + box.height / 2) / imageHeight;
  return (
    centerX >= zone.x &&
    centerX <= zone.x + zone.width &&
    centerY >= zone.y &&
    centerY <= zone.y + zone.height
  );
}

export function isPersonInZone(
  detected: boolean,
  boxes: BoundingBox[],
  zone: DetectionZone | null,
  imageWidth: number,
  imageHeight: number,
): boolean {
  if (!detected) return false;
  if (!zone) return true;
  return boxes.some((box) => isBoundingBoxInZone(box, zone, imageWidth, imageHeight));
}

export class DetectionEventPipeline {
  private activeVisit: VisitState | null = null;
  private readonly recent: DetectionEvent[] = [];
  private cooldownUntil = 0;
  private readonly maxEvents: number;
  private readonly options: DetectionEventOptions;

  constructor(options: DetectionEventOptions) {
    this.options = options;
    if (options.visitGapMs <= 0 || options.cooldownMs < 0) {
      throw new Error("Visit gap must be positive and cooldown cannot be negative");
    }
    this.maxEvents = Math.max(1, options.maxEvents ?? 100);
  }

  update(
    observation: DetectionObservation,
    observedAtMs = Date.now(),
  ): DetectionUpdate {
    const now = Number.isFinite(observedAtMs) ? observedAtMs : Date.now();
    let endedEvent: DetectionEvent | null = null;

    if (!observation.valid) {
      return this.updateResult(false, "unavailable", null);
    }

    if (
      this.activeVisit &&
      now - Date.parse(this.activeVisit.lastSeenAt) >= this.options.visitGapMs
    ) {
      endedEvent = this.finishVisit(now);
    }

    const qualifies =
      observation.personPresent &&
      meetsConfidenceThreshold(observation.confidence, this.options.minimumConfidence);

    if (!qualifies) {
      return this.updateResult(false, endedEvent ? "visit_ended" : "none", endedEvent);
    }

    if (this.activeVisit) {
      this.activeVisit.lastSeenAt = new Date(now).toISOString();
      this.activeVisit.confidence =
        confidenceRank[observation.confidence] >
        confidenceRank[this.activeVisit.confidence]
          ? observation.confidence
          : this.activeVisit.confidence;
      this.activeVisit.personCount = Math.max(
        this.activeVisit.personCount,
        Math.max(1, observation.personCount),
      );
      this.activeVisit.observationCount += 1;
      return this.updateResult(true, "visit_active", null);
    }

    if (now < this.cooldownUntil) {
      return this.updateResult(true, endedEvent ? "visit_ended" : "cooldown_suppressed", endedEvent);
    }

    const visit: VisitState = {
      id: crypto.randomUUID(),
      startedAt: new Date(now).toISOString(),
      lastSeenAt: new Date(now).toISOString(),
      confidence: observation.confidence,
      personCount: Math.max(1, observation.personCount),
      observationCount: 1,
    };
    this.activeVisit = visit;
    this.cooldownUntil = now + this.options.cooldownMs;

    const startedEvent: DetectionEvent = {
      id: crypto.randomUUID(),
      visitId: visit.id,
      type: "visit_started",
      occurredAt: visit.startedAt,
      startedAt: visit.startedAt,
      lastSeenAt: visit.lastSeenAt,
      confidence: visit.confidence,
      personCount: visit.personCount,
    };
    this.record(startedEvent);
    return this.updateResult(true, "visit_started", startedEvent);
  }

  getActiveVisit(): VisitState | null {
    return this.activeVisit ? { ...this.activeVisit } : null;
  }

  getRecentEvents(since?: string): DetectionEvent[] {
    const sinceMs = since ? Date.parse(since) : Number.NEGATIVE_INFINITY;
    if (since && !Number.isFinite(sinceMs)) {
      throw new Error("since must be a valid ISO timestamp");
    }
    return this.recent
      .filter((event) => Date.parse(event.occurredAt) > sinceMs)
      .map((event) => ({ ...event }));
  }

  private finishVisit(now: number): DetectionEvent | null {
    const visit = this.activeVisit;
    if (!visit) return null;

    const event: DetectionEvent = {
      id: crypto.randomUUID(),
      visitId: visit.id,
      type: "visit_ended",
      occurredAt: new Date(now).toISOString(),
      startedAt: visit.startedAt,
      lastSeenAt: visit.lastSeenAt,
      endedAt: new Date(now).toISOString(),
      confidence: visit.confidence,
      personCount: visit.personCount,
    };
    this.activeVisit = null;
    this.record(event);
    return event;
  }

  private record(event: DetectionEvent): void {
    this.recent.push(event);
    if (this.recent.length > this.maxEvents) {
      this.recent.splice(0, this.recent.length - this.maxEvents);
    }
  }

  private updateResult(
    personPresent: boolean,
    eventType: DetectionUpdateType,
    visitEvent: DetectionEvent | null,
  ): DetectionUpdate {
    return {
      personDetected: eventType === "visit_started",
      personPresent,
      eventType,
      visitEvent,
      activeVisit: this.getActiveVisit(),
    };
  }
}
