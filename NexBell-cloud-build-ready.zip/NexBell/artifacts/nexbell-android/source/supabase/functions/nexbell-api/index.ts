import { createClient } from "npm:@supabase/supabase-js@2.57.4";
import {
  isPersonInZone,
  meetsConfidenceThreshold,
  parseDetectionZone,
} from "./detection-events.ts";
import {
  detectWithVisionProviders,
  type VisionDetectionResult,
  type VisionProviderConfig,
} from "./vision-detection.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

if (import.meta.main) {
  Deno.serve(async (req: Request) => {
    if (req.method === "OPTIONS") {
      return new Response(null, { status: 200, headers: corsHeaders });
    }

    try {
      const url = new URL(req.url);
      const path = url.pathname.replace(/^\/nexbell-api/, "").replace(/^\/+/, "");

      if (path === "health" || path === "healthz") {
        return handleHealth(req);
      }
      if (path === "camera/status") {
        return handleCameraStatus(req);
      }
      if (path === "camera/frame") {
        return handleCameraFrame(req);
      }
      if (path === "camera/detect") {
        return handleCameraDetect(req);
      }

      return jsonResponse({ error: "NOT_FOUND", message: "Unknown endpoint: " + path }, 404);
    } catch (err) {
      return jsonResponse(
        { error: "INTERNAL_ERROR", message: (err as Error).message },
        500,
      );
    }
  });
}

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ─── Config ────────────────────────────────────────────────────────

const RED5_HOST = Deno.env.get("RED5_HOST") ?? "userId-3321-e4b2f25a57.cloud.red5.net";
const RED5_STREAM = Deno.env.get("RED5_STREAM") ?? "NexBell";
const RED5_APP = Deno.env.get("RED5_APP") ?? "live";
const RED5_NODE_GROUP = "Baselin-9deA";
const NVIDIA_API_KEY = Deno.env.get("NVIDIA_API_KEY") ?? "";
const NVIDIA_VLM_MODEL = Deno.env.get("NVIDIA_VLM_MODEL") ?? "meta/llama-3.2-11b-vision-instruct";
const NVIDIA_API_BASE = Deno.env.get("NVIDIA_API_BASE") ?? "https://integrate.api.nvidia.com/v1";
const SARVAM_API_KEY = Deno.env.get("SARVAM_API_KEY") ?? "";
const SARVAM_VLM_MODEL = Deno.env.get("SARVAM_VLM_MODEL") ?? "gemma4";
const SARVAM_API_BASE = Deno.env.get("SARVAM_API_BASE") ?? "https://api.sarvam.ai/v2";

// ─── Health ────────────────────────────────────────────────────────

function handleHealth(_req: Request): Response {
  if (import.meta.main) {
    return jsonResponse({
      status: "ONLINE",
      timestamp: new Date().toISOString(),
      version: "0.1.0",
      nvidiaKeyConfigured: !!NVIDIA_API_KEY,
      sarvamKeyConfigured: !!SARVAM_API_KEY,
    });
  }
  return jsonResponse({ status: "ALIVE", uptime: 0 });
}

// ─── Camera Status ─────────────────────────────────────────────────

interface Red5Stream {
  streamGuid?: string;
  serverAddress?: string;
  state?: string;
  nodeRole?: string;
  subGroup?: string;
  nodeState?: string;
  streamSource?: string;
  durationMs?: number;
}

async function probeRed5(): Promise<{
  state: "online" | "offline" | "unknown";
  edgeServer?: string;
  streamState?: string;
  note: string;
}> {
  const streamGuid = `${RED5_APP}/${RED5_STREAM}`;
  const apiUrl = `https://${RED5_HOST}/as/v1/streams/stream/${RED5_NODE_GROUP}/subscribe/${streamGuid}`;

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 5000);
    const res = await fetch(apiUrl, {
      signal: controller.signal,
      headers: { Accept: "application/json" },
    });
    clearTimeout(timeout);

    if (res.ok) {
      const body = await res.json().catch(() => null);
      const streams: Red5Stream[] = Array.isArray(body) ? body : body ? [body] : [];
      const live = streams.find((s) => s.state === "LIVE");
      if (live) {
        return {
          state: "online",
          edgeServer: live.serverAddress,
          streamState: "LIVE",
          note: "Camera stream is live on Red5 Pro Stream Manager.",
        };
      }
      const available = streams.find((s) => s.state === "AVAILABLE");
      if (available) {
        return {
          state: "offline",
          streamState: "AVAILABLE",
          note: "Stream exists but is not actively publishing media.",
        };
      }
      return {
        state: "offline",
        streamState: streams[0]?.state ?? "UNKNOWN",
        note: "Stream responded but no LIVE or AVAILABLE state found.",
      };
    }

    if (res.status === 404) {
      const body = await res.json().catch(() => ({}));
      return {
        state: "offline",
        streamState: "NOT_LIVE",
        note: `Camera stream is not currently published. Red5 reports: "${body.error ?? "Stream not found"}"`,
      };
    }

    return {
      state: "unknown",
      note: `Unexpected response from Stream Manager: HTTP ${res.status}`,
    };
  } catch (err) {
    const isAbort = err instanceof DOMException && err.name === "AbortError";
    return {
      state: "unknown",
      note: isAbort
        ? "Probe timed out (5s). Camera status unknown."
        : `Probe failed: ${(err as Error).message}`,
    };
  }
}

async function handleCameraStatus(_req: Request): Promise<Response> {
  const status = await probeRed5();
  return jsonResponse({
    status: status.state,
    streamState: status.streamState,
    model: "GODSB06",
    stream: { host: RED5_HOST, app: RED5_APP, name: RED5_STREAM },
    edgeServer: status.edgeServer,
    lastChecked: new Date().toISOString(),
    note: status.note,
  });
}

// ─── Frame Capture ─────────────────────────────────────────────────

async function captureFrame(rtmpUrl: string): Promise<{ data: Uint8Array; width: number; height: number }> {
  const tmpFile = `/tmp/nexbell_frame_${Date.now()}.jpg`;

  const cmd = new Deno.Command("ffmpeg", {
    args: ["-y", "-i", rtmpUrl, "-frames:v", "1", "-update", "1", "-f", "image2", tmpFile],
    timeout: 15000,
    stdout: "piped",
    stderr: "piped",
  });

  const { code, stderr } = await cmd.output();
  if (code !== 0) {
    const stderrText = new TextDecoder().decode(stderr);
    throw new Error(`ffmpeg failed (exit ${code}): ${stderrText.slice(0, 500)}`);
  }

  const data = await Deno.readFile(tmpFile);
  await Deno.remove(tmpFile).catch(() => {});

  const stderrText = new TextDecoder().decode(stderr);
  const dimMatch = stderrText.match(/(\d+)x(\d+)/);
  const width = dimMatch ? parseInt(dimMatch[1], 10) : 0;
  const height = dimMatch ? parseInt(dimMatch[2], 10) : 0;

  if (data.length === 0) {
    throw new Error("Frame capture produced an empty file");
  }

  return { data, width, height };
}

async function handleCameraFrame(_req: Request): Promise<Response> {
  const status = await probeRed5();

  if (status.state !== "online" || !status.edgeServer) {
    return jsonResponse({
      error: "STREAM_OFFLINE",
      message: "Camera stream is not live. Cannot capture frame.",
      streamState: status.streamState,
    }, 503);
  }

  const rtmpUrl = `rtmp://${status.edgeServer}:1935/${RED5_APP}/${RED5_STREAM}`;

  try {
    const frame = await captureFrame(rtmpUrl);
    return new Response(frame.data, {
      status: 200,
      headers: {
        "Content-Type": "image/jpeg",
        "Content-Length": String(frame.data.length),
        "X-Frame-Source": rtmpUrl,
        "X-Frame-Dimensions": `${frame.width}x${frame.height}`,
        ...corsHeaders,
      },
    });
  } catch (err) {
    return jsonResponse({
      error: "FRAME_CAPTURE_FAILED",
      message: "Failed to capture frame from RTMP stream.",
      detail: (err as Error).message,
    }, 502);
  }
}

// ─── AI Detection ──────────────────────────────────────────────────

interface DetectionResult {
  personDetected: boolean;
  confidence: "high" | "medium" | "low" | "unknown";
  confidenceReason: string;
  description: string;
  boundingBoxes: Array<{ x: number; y: number; width: number; height: number }>;
  model: string;
  endpoint: string;
  provider: "nvidia" | "none";
  capturedAt: string;
  frameSize: number;
  sourceImageUrl: string;
  rawResponse: unknown;
  error?: string;
}

const DETECTION_PROMPT =
  'Analyze this image from a doorbell security camera. Answer in JSON format with these fields: ' +
  '"person_detected" (true/false), "confidence" (high/medium/low), "description" (brief description of what you see), ' +
  '"person_count" (number of people visible, 0 if none), "bounding_boxes" (array of {x, y, width, height} in pixels ' +
  'if person detected, empty array if not). Only output the JSON, no other text.';

function noKeyResult(): DetectionResult {
  return {
    personDetected: false,
    confidence: "unknown",
    confidenceReason: "No NVIDIA API key configured",
    description: "",
    boundingBoxes: [],
    model: NVIDIA_VLM_MODEL,
    endpoint: NVIDIA_API_BASE,
    provider: "none",
    capturedAt: new Date().toISOString(),
    frameSize: 0,
    sourceImageUrl: "",
    rawResponse: null,
    error: "AI_API_KEY_MISSING",
  };
}

function extractJson(text: string): Record<string, unknown> | null {
  const jsonMatch = text.match(/\{[\s\S]*\}/);
  if (!jsonMatch) return null;
  try {
    return JSON.parse(jsonMatch[0]);
  } catch {
    return null;
  }
}

function normalizeConfidence(raw: string): DetectionResult["confidence"] {
  const lower = raw.toLowerCase();
  if (lower === "high") return "high";
  if (lower === "medium") return "medium";
  if (lower === "low") return "low";
  return "unknown";
}

async function callNvidia(
  base64Image: string,
  frameSize: number,
  sourceUrl: string,
): Promise<DetectionResult> {
  const dataUrl = `data:image/jpeg;base64,${base64Image}`;
  const endpoint = `${NVIDIA_API_BASE}/chat/completions`;

  const body = {
    model: NVIDIA_VLM_MODEL,
    messages: [
      {
        role: "user",
        content: [
          { type: "image_url", image_url: { url: dataUrl } },
          { type: "text", text: DETECTION_PROMPT },
        ],
      },
    ],
    max_tokens: 512,
    temperature: 0.2,
    top_p: 1,
    stream: false,
  };

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);

  try {
    const res = await fetch(endpoint, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${NVIDIA_API_KEY}`,
      },
      body: JSON.stringify(body),
    });
    clearTimeout(timeout);

    const rawJson = await res.json().catch(() => null);

    if (!res.ok) {
      return {
        personDetected: false,
        confidence: "unknown",
        confidenceReason: `NVIDIA API returned HTTP ${res.status}`,
        description: "",
        boundingBoxes: [],
        model: NVIDIA_VLM_MODEL,
        endpoint,
        provider: "nvidia",
        capturedAt: new Date().toISOString(),
        frameSize,
        sourceImageUrl: sourceUrl,
        rawResponse: rawJson,
        error: `NVIDIA_API_ERROR_${res.status}`,
      };
    }

    const text = rawJson?.choices?.[0]?.message?.content ?? "";
    const parsed = extractJson(text);
    const personDetected = parsed?.person_detected === true;
    const confidenceRaw = String(parsed?.confidence ?? "");
    const confidence = normalizeConfidence(confidenceRaw);

    const boundingBoxes: DetectionResult["boundingBoxes"] = [];
    if (Array.isArray(parsed?.bounding_boxes)) {
      for (const b of parsed.bounding_boxes) {
        if (typeof b === "object" && b !== null && typeof b.x === "number" && typeof b.y === "number") {
          boundingBoxes.push({
            x: b.x,
            y: b.y,
            width: typeof b.width === "number" ? b.width : 0,
            height: typeof b.height === "number" ? b.height : 0,
          });
        }
      }
    }

    return {
      personDetected,
      confidence,
      confidenceReason: confidence
        ? `NVIDIA VLM reported ${confidence} confidence`
        : "NVIDIA VLM did not report confidence level",
      description: String(parsed?.description ?? text.substring(0, 200)),
      boundingBoxes,
      model: NVIDIA_VLM_MODEL,
      endpoint,
      provider: "nvidia",
      capturedAt: new Date().toISOString(),
      frameSize,
      sourceImageUrl: sourceUrl,
      rawResponse: rawJson,
    };
  } catch (err) {
    clearTimeout(timeout);
    const isAbort = err instanceof DOMException && err.name === "AbortError";
    return {
      personDetected: false,
      confidence: "unknown",
      confidenceReason: isAbort
        ? "NVIDIA request timed out (30s)"
        : "NVIDIA request failed",
      description: "",
      boundingBoxes: [],
      model: NVIDIA_VLM_MODEL,
      endpoint,
      provider: "nvidia",
      capturedAt: new Date().toISOString(),
      frameSize,
      sourceImageUrl: sourceUrl,
      rawResponse: null,
      error: (err as Error).message,
    };
  }
}

async function handleCameraDetect(_req: Request): Promise<Response> {
  const providers: VisionProviderConfig[] = [];
  if (NVIDIA_API_KEY) {
    providers.push({
      name: "nvidia",
      model: NVIDIA_VLM_MODEL,
      apiBase: NVIDIA_API_BASE,
      apiKey: NVIDIA_API_KEY,
    });
  }
  if (SARVAM_API_KEY) {
    providers.push({
      name: "sarvam",
      model: SARVAM_VLM_MODEL,
      apiBase: SARVAM_API_BASE,
      apiKey: SARVAM_API_KEY,
    });
  }
  if (providers.length === 0) {
    return jsonResponse({
      ...noKeyResult(),
      error: "AI_API_KEY_MISSING",
      confidenceReason: "No NVIDIA or Sarvam API key is configured",
    }, 503);
  }

  const status = await probeRed5();
  if (status.state !== "online" || !status.edgeServer) {
    return jsonResponse({
      personDetected: false,
      confidence: "unknown",
      confidenceReason: "Camera stream is not live",
      description: "",
      boundingBoxes: [],
      model: NVIDIA_VLM_MODEL,
      endpoint: NVIDIA_API_BASE,
      provider: "none",
      capturedAt: new Date().toISOString(),
      frameSize: 0,
      sourceImageUrl: "",
      rawResponse: null,
      error: "STREAM_OFFLINE",
    }, 503);
  }

  const rtmpUrl = `rtmp://${status.edgeServer}:1935/${RED5_APP}/${RED5_STREAM}`;

  try {
    const frame = await captureFrame(rtmpUrl);

    if (frame.data.length > 4 * 1024 * 1024) {
      return jsonResponse({
        error: "FRAME_TOO_LARGE",
        message: `Frame too large: ${frame.data.length} bytes`,
      }, 500);
    }

    const base64 = btoa(String.fromCharCode(...frame.data));
    const result: VisionDetectionResult = await detectWithVisionProviders(
      base64,
      frame.data.length,
      rtmpUrl,
      providers,
    );
    if (result.error) {
      return jsonResponse(result, 503);
    }

    let zone;
    try {
      zone = parseDetectionZone(Deno.env.get("NEXBELL_DETECTION_ZONE"));
    } catch {
      return jsonResponse({
        ...result,
        personDetected: false,
        alertEligible: false,
        zoneConfigured: false,
        error: "DETECTION_ZONE_INVALID",
        confidenceReason: "The configured detection zone is invalid; visitor alerts are disabled.",
      }, 503);
    }

    const personInZone = zone !== null && isPersonInZone(
      result.personDetected,
      result.boundingBoxes,
      zone,
      frame.width,
      frame.height,
    );
    const alertEligible =
      zone !== null &&
      personInZone &&
      meetsConfidenceThreshold(result.confidence, "medium");

    return jsonResponse({
      ...result,
      modelPersonDetected: result.personDetected,
      personDetected: alertEligible,
      personInZone,
      alertEligible,
      zoneConfigured: zone !== null,
      frameWidth: frame.width,
      frameHeight: frame.height,
      confidenceReason: zone
        ? result.confidenceReason
        : "No entrance detection zone is configured; visitor alerts are disabled.",
    }, 200);
  } catch (err) {
    return jsonResponse({
      error: "DETECTION_FAILED",
      message: "Person detection failed.",
      detail: (err as Error).message,
    }, 500);
  }
}
