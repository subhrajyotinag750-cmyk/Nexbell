import assert from "node:assert/strict";
import test from "node:test";
import {
  detectWithVisionProviders,
  parseVisionContent,
} from "../vision-detection.ts";

const modelPayload = (content) => ({
  choices: [{ message: { content: JSON.stringify(content) } }],
});

test("parses person boxes and non-trigger object categories", () => {
  const result = parseVisionContent(JSON.stringify({
    person_detected: true,
    person_count: 2,
    object_types: ["person", "insect", "vehicle", "not-allowed"],
    confidence: "high",
    description: "Two people near the entrance.",
    bounding_boxes: [{ x: 10, y: 20, width: 30, height: 80 }],
  }));

  assert.equal(result.personDetected, true);
  assert.equal(result.personCount, 2);
  assert.deepEqual(result.objectTypes, ["person", "insect", "vehicle"]);
  assert.deepEqual(result.boundingBoxes, [{ x: 10, y: 20, width: 30, height: 80 }]);
});

test("malformed model output is not treated as an empty-scene result", () => {
  assert.equal(parseVisionContent("not JSON"), null);
  assert.equal(parseVisionContent('{"confidence":"high"}'), null);
});

test("NVIDIA is tried first and Sarvam is used after provider failure", async () => {
  const calls = [];
  const providers = [
    { name: "nvidia", model: "nvidia-model", apiBase: "https://nvidia.test/v1", apiKey: "nvidia-test" },
    { name: "sarvam", model: "sarvam-model", apiBase: "https://sarvam.test/v2", apiKey: "sarvam-test" },
  ];

  const result = await detectWithVisionProviders(
    "aGVsbG8=",
    1234,
    "rtmp://camera.test/live",
    providers,
    async (url) => {
      calls.push(url);
      if (url.startsWith("https://nvidia.test/")) {
        return new Response(JSON.stringify({ error: "temporary" }), { status: 503 });
      }
      return new Response(JSON.stringify(modelPayload({
        person_detected: false,
        person_count: 0,
        object_types: ["insect"],
        confidence: "medium",
        description: "An insect is visible.",
        bounding_boxes: [],
      })), { status: 200 });
    },
  );

  assert.deepEqual(calls, [
    "https://nvidia.test/v1/chat/completions",
    "https://sarvam.test/v2/chat/completions",
  ]);
  assert.equal(result.provider, "sarvam");
  assert.equal(result.personDetected, false);
  assert.deepEqual(result.objectTypes, ["insect"]);
});

test("a valid NVIDIA result avoids an unnecessary Sarvam request", async () => {
  let calls = 0;
  const result = await detectWithVisionProviders(
    "aGVsbG8=",
    1234,
    "rtmp://camera.test/live",
    [
      { name: "nvidia", model: "nvidia-model", apiBase: "https://nvidia.test/v1", apiKey: "nvidia-test" },
      { name: "sarvam", model: "sarvam-model", apiBase: "https://sarvam.test/v2", apiKey: "sarvam-test" },
    ],
    async () => {
      calls += 1;
      return new Response(JSON.stringify(modelPayload({
        person_detected: true,
        person_count: 1,
        object_types: ["person"],
        confidence: "high",
        description: "A person is visible.",
        bounding_boxes: [],
      })), { status: 200 });
    },
  );

  assert.equal(calls, 1);
  assert.equal(result.provider, "nvidia");
  assert.equal(result.personDetected, true);
});
