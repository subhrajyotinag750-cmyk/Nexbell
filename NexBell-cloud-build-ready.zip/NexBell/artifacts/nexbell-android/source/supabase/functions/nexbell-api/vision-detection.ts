export type VisionProviderName = "nvidia" | "sarvam" | "none";
export type DetectionConfidence = "high" | "medium" | "low" | "unknown";
export type DetectedObjectType =
  | "person"
  | "insect"
  | "vehicle"
  | "animal"
  | "motion"
  | "uncertain";

export interface BoundingBox {
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface VisionProviderConfig {
  name: Exclude<VisionProviderName, "none">;
  model: string;
  apiBase: string;
  apiKey: string;
}

export interface VisionDetectionResult {
  personDetected: boolean;
  personCount: number;
  objectTypes: DetectedObjectType[];
  confidence: DetectionConfidence;
  confidenceReason: string;
  description: string;
  boundingBoxes: BoundingBox[];
  model: string;
  endpoint: string;
  provider: VisionProviderName;
  capturedAt: string;
  frameSize: number;
  sourceImageUrl: string;
  rawResponse: unknown;
  error?: string;
}

interface ParsedVisionContent {
  personDetected: boolean;
  personCount: number;
  objectTypes: DetectedObjectType[];
  confidence: DetectionConfidence;
  description: string;
  boundingBoxes: BoundingBox[];
}

const allowedObjectTypes = new Set<DetectedObjectType>([
  "person",
  "insect",
  "vehicle",
  "animal",
  "motion",
  "uncertain",
]);

export const VISION_DETECTION_PROMPT =
  "Inspect this real doorbell-camera frame. Return only a JSON object with: " +
  '"person_detected" (boolean; true only when a person is visibly present), ' +
  '"person_count" (integer, zero when none), ' +
  '"object_types" (array containing only person, insect, vehicle, animal, motion, uncertain), ' +
  '"confidence" (high, medium, low, or unknown), ' +
  '"description" (short factual description), and ' +
  '"bounding_boxes" (one {x,y,width,height} pixel box for each visible person; empty if none). ' +
  "Do not infer a person from shadows, reflections, or general motion. Do not infer approach or intent from one still frame.";

function normalizeConfidence(value: unknown): DetectionConfidence {
  if (typeof value !== "string") return "unknown";
  const confidence = value.toLowerCase();
  return confidence === "high" || confidence === "medium" || confidence === "low"
    ? confidence
    : "unknown";
}

function responseContent(raw: unknown): string {
  if (!raw || typeof raw !== "object") return "";
  const choices = (raw as { choices?: unknown[] }).choices;
  if (!Array.isArray(choices) || !choices[0] || typeof choices[0] !== "object") return "";
  const message = (choices[0] as { message?: unknown }).message;
  if (!message || typeof message !== "object") return "";
  const content = (message as { content?: unknown }).content;
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => {
        if (!part || typeof part !== "object") return "";
        const text = (part as { text?: unknown }).text;
        return typeof text === "string" ? text : "";
      })
      .join("\n");
  }
  return "";
}

function parseJsonObject(text: string): Record<string, unknown> | null {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return null;
  try {
    const value: unknown = JSON.parse(match[0]);
    return typeof value === "object" && value !== null
      ? (value as Record<string, unknown>)
      : null;
  } catch {
    return null;
  }
}

export function parseVisionContent(content: string): ParsedVisionContent | null {
  const parsed = parseJsonObject(content);
  if (!parsed || typeof parsed.person_detected !== "boolean") return null;

  const objectTypes = Array.isArray(parsed.object_types)
    ? [...new Set(
        parsed.object_types.filter(
          (value): value is DetectedObjectType =>
            typeof value === "string" && allowedObjectTypes.has(value as DetectedObjectType),
        ),
      )]
    : [];
  if (parsed.person_detected && !objectTypes.includes("person")) {
    objectTypes.push("person");
  }

  const boundingBoxes: BoundingBox[] = [];
  if (Array.isArray(parsed.bounding_boxes)) {
    for (const value of parsed.bounding_boxes) {
      if (!value || typeof value !== "object") continue;
      const box = value as Record<string, unknown>;
      if (
        typeof box.x === "number" &&
        typeof box.y === "number" &&
        typeof box.width === "number" &&
        typeof box.height === "number" &&
        [box.x, box.y, box.width, box.height].every(Number.isFinite) &&
        box.x >= 0 &&
        box.y >= 0 &&
        box.width > 0 &&
        box.height > 0
      ) {
        boundingBoxes.push({
          x: box.x,
          y: box.y,
          width: box.width,
          height: box.height,
        });
      }
    }
  }

  const rawCount = parsed.person_count;
  const personCount =
    typeof rawCount === "number" && Number.isFinite(rawCount) && rawCount >= 0
      ? Math.floor(rawCount)
      : parsed.person_detected
        ? 1
        : 0;

  return {
    personDetected: parsed.person_detected,
    personCount,
    objectTypes,
    confidence: normalizeConfidence(parsed.confidence),
    description:
      typeof parsed.description === "string" ? parsed.description.slice(0, 500) : "",
    boundingBoxes,
  };
}

function failedResult(
  provider: VisionProviderName,
  model: string,
  endpoint: string,
  frameSize: number,
  sourceImageUrl: string,
  error: string,
  rawResponse: unknown = null,
): VisionDetectionResult {
  return {
    personDetected: false,
    personCount: 0,
    objectTypes: [],
    confidence: "unknown",
    confidenceReason: error,
    description: "",
    boundingBoxes: [],
    model,
    endpoint,
    provider,
    capturedAt: new Date().toISOString(),
    frameSize,
    sourceImageUrl,
    rawResponse,
    error,
  };
}

export async function detectWithVisionProviders(
  base64Image: string,
  frameSize: number,
  sourceImageUrl: string,
  providers: VisionProviderConfig[],
  fetcher: typeof fetch = fetch,
): Promise<VisionDetectionResult> {
  const configuredProviders = providers.filter((provider) => provider.apiKey.trim());
  if (configuredProviders.length === 0) {
    return failedResult(
      "none",
      "",
      "",
      frameSize,
      sourceImageUrl,
      "AI_API_KEY_MISSING",
    );
  }

  let lastFailure: VisionDetectionResult | null = null;
  for (const provider of configuredProviders) {
    const endpoint = `${provider.apiBase.replace(/\/+$/, "")}/chat/completions`;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 30_000);

    try {
      const response = await fetcher(endpoint, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${provider.apiKey}`,
        },
        body: JSON.stringify({
          model: provider.model,
          messages: [
            {
              role: "user",
              content: [
                {
                  type: "image_url",
                  image_url: { url: `data:image/jpeg;base64,${base64Image}` },
                },
                { type: "text", text: VISION_DETECTION_PROMPT },
              ],
            },
          ],
          max_tokens: 512,
          temperature: 0.2,
          top_p: 1,
          stream: false,
        }),
      });

      const rawResponse = await response.json().catch(() => null);
      if (!response.ok) {
        lastFailure = failedResult(
          provider.name,
          provider.model,
          endpoint,
          frameSize,
          sourceImageUrl,
          `${provider.name.toUpperCase()}_API_ERROR_${response.status}`,
          rawResponse,
        );
        continue;
      }

      const parsed = parseVisionContent(responseContent(rawResponse));
      if (!parsed) {
        lastFailure = failedResult(
          provider.name,
          provider.model,
          endpoint,
          frameSize,
          sourceImageUrl,
          "INVALID_MODEL_RESPONSE",
          rawResponse,
        );
        continue;
      }

      return {
        ...parsed,
        confidenceReason: `${provider.name} vision model reported ${parsed.confidence} confidence`,
        model: provider.model,
        endpoint,
        provider: provider.name,
        capturedAt: new Date().toISOString(),
        frameSize,
        sourceImageUrl,
        rawResponse,
      };
    } catch (error) {
      const timedOut = error instanceof DOMException && error.name === "AbortError";
      lastFailure = failedResult(
        provider.name,
        provider.model,
        endpoint,
        frameSize,
        sourceImageUrl,
        timedOut ? `${provider.name.toUpperCase()}_TIMEOUT` : `${provider.name.toUpperCase()}_REQUEST_FAILED`,
      );
    } finally {
      clearTimeout(timeout);
    }
  }

  return lastFailure ?? failedResult(
    "none",
    "",
    "",
    frameSize,
    sourceImageUrl,
    "AI_PROVIDER_UNAVAILABLE",
  );
}
