import assert from "node:assert/strict";
import test from "node:test";
import {
  DetectionEventPipeline,
  isPersonInZone,
  meetsConfidenceThreshold,
  parseDetectionZone,
} from "../detection-events.ts";

const seconds = (value) => value * 1000;
const sample = (overrides = {}) => ({
  valid: true,
  personPresent: true,
  confidence: "high",
  personCount: 1,
  ...overrides,
});
const pipeline = (overrides = {}) =>
  new DetectionEventPipeline({
    minimumConfidence: "medium",
    visitGapMs: seconds(60),
    cooldownMs: seconds(120),
    ...overrides,
  });

test("a visit produces one start event for consecutive positive observations", () => {
  const events = pipeline();
  const first = events.update(sample(), seconds(100));
  const second = events.update(sample({ confidence: "medium" }), seconds(130));

  assert.equal(first.eventType, "visit_started");
  assert.equal(first.personDetected, true);
  assert.equal(second.eventType, "visit_active");
  assert.equal(second.personDetected, false);
  assert.equal(second.personPresent, true);
  assert.equal(events.getRecentEvents().filter((event) => event.type === "visit_started").length, 1);
  assert.equal(second.activeVisit.observationCount, 2);
});

test("low and unknown confidence do not start a visit", () => {
  const events = pipeline();
  assert.equal(
    events.update(sample({ confidence: "low" }), seconds(100)).eventType,
    "none",
  );
  assert.equal(
    events.update(sample({ confidence: "unknown" }), seconds(130)).eventType,
    "none",
  );
  assert.equal(events.getActiveVisit(), null);
  assert.equal(meetsConfidenceThreshold("low", "medium"), false);
});

test("provider failures do not end an active visit", () => {
  const events = pipeline();
  events.update(sample(), seconds(100));
  const result = events.update(sample({ valid: false, personPresent: false }), seconds(200));

  assert.equal(result.eventType, "unavailable");
  assert.equal(result.activeVisit.startedAt, new Date(seconds(100)).toISOString());
  assert.equal(events.getRecentEvents().filter((event) => event.type === "visit_ended").length, 0);
});

test("a visit ends only after the configured no-person gap", () => {
  const events = pipeline();
  events.update(sample(), seconds(100));
  const beforeGap = events.update(sample({ personPresent: false }), seconds(159));
  const afterGap = events.update(sample({ personPresent: false }), seconds(160));

  assert.equal(beforeGap.activeVisit !== null, true);
  assert.equal(afterGap.eventType, "visit_ended");
  assert.equal(afterGap.activeVisit, null);
  assert.equal(events.getRecentEvents().at(-1).type, "visit_ended");
});

test("cooldown prevents a new visit event immediately after a completed visit", () => {
  const events = pipeline({ visitGapMs: seconds(10), cooldownMs: seconds(120) });
  events.update(sample(), seconds(100));
  events.update(sample({ personPresent: false }), seconds(110));
  const suppressed = events.update(sample(), seconds(150));

  assert.equal(suppressed.eventType, "cooldown_suppressed");
  assert.equal(suppressed.personDetected, false);
  assert.equal(events.getRecentEvents().filter((event) => event.type === "visit_started").length, 1);
});

test("normalized detection zones select only boxes whose centers fall inside", () => {
  const zone = parseDetectionZone('{"x":0.25,"y":0.25,"width":0.5,"height":0.5}');
  assert.equal(
    isPersonInZone(true, [{ x: 80, y: 80, width: 40, height: 40 }], zone, 200, 200),
    true,
  );
  assert.equal(
    isPersonInZone(true, [{ x: 0, y: 0, width: 20, height: 20 }], zone, 200, 200),
    false,
  );
  assert.equal(isPersonInZone(true, [], zone, 200, 200), false);
  assert.equal(isPersonInZone(true, [], null, 0, 0), true);
});

test("invalid zone values fail closed", () => {
  assert.equal(parseDetectionZone(undefined), null);
  assert.throws(
    () => parseDetectionZone('{"x":0.8,"y":0,"width":0.5,"height":1}'),
    /normalized/,
  );
  assert.throws(() => parseDetectionZone("{"), /valid JSON/);
});
