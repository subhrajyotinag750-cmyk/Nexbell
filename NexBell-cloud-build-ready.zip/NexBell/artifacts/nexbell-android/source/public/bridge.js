/**
 * NexBell Backend Bridge
 * ----------------------
 * Connects the Red5 live stream and detection backend to the existing
 * NexBell UI without modifying NexBell.html.
 *
 * Video: Uses the Red5 Pro WebRTC SDK (WHEPClient) to subscribe directly
 * to the live stream, bypassing the nested-iframe restriction that causes
 * "embed.red5.net refused to connect" inside sandboxed preview environments.
 *
 * AI: Calls the deployed NexBell FastAPI middleware for
 * health, backend status, and camera-frame classification. Maps the backend
 * response to the NexBell.setState() API the UI already exposes.
 */
(function () {
  'use strict';

  if (!window.NexBell || !window.NexBell.setState) {
    console.warn('[NexBell Bridge] NexBell integration API not found — bridge inactive.');
    return;
  }

  // ─── Red5 stream configuration (must match NexBell.html) ───────────
  var RED5_HOST = 'userId-3321-e4b2f25a57.cloud.red5.net';
  var RED5_APP = 'live';
  var RED5_STREAM = 'NexBell';
  var RED5_NODE_GROUP = 'Baselin-9deA';
  var RED5_API_VERSION = 'v1';
  var SDK_URL = 'https://cdn.jsdelivr.net/npm/red5pro-webrtc-sdk@latest/red5pro-sdk.min.js';
  var ADAPTER_URL = 'https://webrtchacks.github.io/adapter/adapter-latest.js';

  // ─── Backend API (deployed NexBell FastAPI middleware) ─────────────
  // Set apiBaseUrl to the backend origin (for example https://host.example).
  // Set apiToken to the API_AUTH_TOKEN configured on the backend.
  var configuredApiBase = window.NEXBELL_CONFIG && window.NEXBELL_CONFIG.apiBaseUrl;
  var API_BASE = String(configuredApiBase || '').trim().replace(/\/+$/, '');
  var API_TOKEN = String((window.NEXBELL_CONFIG && window.NEXBELL_CONFIG.apiToken) || '').trim();
  var API_HEADERS = { 'Content-Type': 'application/json' };
  if (API_TOKEN) API_HEADERS.Authorization = 'Bearer ' + API_TOKEN;

  // ─── AI detection polling ──────────────────────────────────────────
  var POLL_INTERVAL = 30000;
  var timer = null;
  var consecutiveErrors = 0;
  var MAX_ERRORS = 3;
  var personVisitActive = false;
  var noPersonResults = 0;

  var videoElement = null;
  var subscriber = null;
  var retryCount = 0;
  var MAX_RETRIES = 20;
  var retryTimeout = null;
  var shuttingDown = false;

  function log(msg) {
    console.log('[NexBell Bridge] ' + msg);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  VIDEO — Direct WHEP/WebRTC subscription
  // ═══════════════════════════════════════════════════════════════════

  function loadScript(src, onload, onerror) {
    var s = document.createElement('script');
    s.src = src;
    s.onload = onload;
    s.onerror = onerror || function () { log('Failed to load script: ' + src); };
    document.head.appendChild(s);
  }

  function setVideoState(state, msg) {
    // Map to NexBell UI states
    if (state === 'connecting') {
      NexBell.setState({ video: 'ok' }); // UI shows camera area; we overlay our own status
      showOverlay('CONNECTING', msg || 'Connecting to camera…');
    } else if (state === 'live') {
      NexBell.setState({ video: 'ok' });
      hideOverlay();
    } else if (state === 'offline' || state === 'error') {
      NexBell.setState({
        video: 'unavailable',
        videoMsg: msg || 'The live stream could not be started.',
      });
      showOverlay(state === 'offline' ? 'OFFLINE' : 'PLAYBACK ERROR', msg);
    }
  }

  function showOverlay(label, msg) {
    var cam = document.querySelector('#live-s .cam');
    if (!cam) return;
    var ov = cam.querySelector('.nb-bridge-overlay');
    if (!ov) {
      ov = document.createElement('div');
      ov.className = 'nb-bridge-overlay';
      ov.style.cssText = 'position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:5;background:rgba(2,5,11,.85);border-radius:inherit;text-align:center;padding:20px';
      cam.appendChild(ov);
    }
    var dot = label === 'LIVE' ? '' : '<div style="width:8px;height:8px;border-radius:50%;background:#ffb454;margin:0 auto 10px;animation:p 1.4s infinite"></div>';
    ov.innerHTML = dot + '<div style="font-size:13px;font-weight:700;color:#7fb0ff;letter-spacing:.5px">' + label + '</div>' +
      (msg ? '<div style="font-size:11px;color:#8d9ab3;margin-top:6px;max-width:220px;line-height:1.4">' + msg + '</div>' : '');
  }

  function hideOverlay() {
    var cam = document.querySelector('#live-s .cam');
    if (!cam) return;
    var ov = cam.querySelector('.nb-bridge-overlay');
    if (ov) ov.remove();
  }

  function initVideoElement() {
    var cam = document.querySelector('#live-s .cam');
    if (!cam) {
      log('Camera container not found, retrying…');
      setTimeout(initVideoElement, 500);
      return;
    }

    // Create video element
    videoElement = document.createElement('video');
    videoElement.autoplay = true;
    videoElement.playsInline = true;
    videoElement.muted = true;
    videoElement.controls = false;
    videoElement.style.cssText = 'position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:4;border-radius:inherit;background:transparent';

    // Insert into camera container
    var ph = cam.querySelector('.ph');
    if (ph) {
      ph.style.display = 'none';
      cam.insertBefore(videoElement, ph);
    } else {
      cam.appendChild(videoElement);
    }

    setVideoState('connecting', 'Establishing WebRTC connection to Red5 Pro…');

    // Load WebRTC adapter then SDK then subscribe
    loadScript(ADAPTER_URL, function () {
      loadScript(SDK_URL, function () {
        log('Red5 Pro WebRTC SDK loaded');
        subscribe();
      }, function () {
        setVideoState('error', 'Failed to load the Red5 Pro WebRTC SDK.');
      });
    }, function () {
      setVideoState('error', 'Failed to load the WebRTC adapter.');
    });
  }

  function subscribe() {
    if (!window.red5 || !window.red5.WHEPClient) {
      setVideoState('error', 'Red5 Pro SDK not available.');
      return;
    }

    var config = {
      host: RED5_HOST,
      endpoint: 'https://' + RED5_HOST + '/as/' + RED5_API_VERSION + '/proxy/whep/' + RED5_APP + '/' + RED5_STREAM,
      streamName: RED5_STREAM,
      connectionParams: {
        nodeGroup: RED5_NODE_GROUP,
      },
      mediaElement: videoElement,
    };

    log('Subscribing via WHEP: ' + config.endpoint);

    try {
      subscriber = new window.red5.WHEPClient();
    } catch (e) {
      setVideoState('error', 'WHEPClient could not be created: ' + e.message);
      return;
    }

    subscriber.on('*', function (event) {
      var type = event && event.type ? event.type : 'unknown';
      log('Subscriber event: ' + type);

      if (type === 'subscribe.play') {
        retryCount = 0;
        setVideoState('live');
        log('Stream is LIVE — video playing');
      } else if (
        type === window.red5.SubscriberEventTypes.CONNECTION_CLOSED ||
        type === window.red5.SubscriberEventTypes.CONNECT_FAILURE ||
        type === window.red5.SubscriberEventTypes.PLAY_UNPUBLISH
      ) {
        setVideoState('offline', 'Stream disconnected. Retrying…');
        retrySubscribe();
      }
    });

    subscriber.init(config).then(function () {
      return subscriber.subscribe();
    }).catch(function (e) {
      log('Subscribe failed: ' + (e && e.message ? e.message : String(e)));
      setVideoState('error', 'Failed to subscribe to the stream: ' + (e && e.message ? e.message : 'unknown error'));
      retrySubscribe();
    });
  }

  function retrySubscribe() {
    if (retryTimeout) {
      clearTimeout(retryTimeout);
      retryTimeout = null;
    }
    if (shuttingDown || retryCount >= MAX_RETRIES) {
      if (retryCount >= MAX_RETRIES) {
        setVideoState('error', 'Max retries reached. Tap Retry to try again.');
      }
      return;
    }
    retryCount++;
    log('Retry ' + retryCount + '/' + MAX_RETRIES + ' in 2s…');
    retryTimeout = setTimeout(function () {
      retryTimeout = null;
      unsubscribe().then(function () {
        subscribe();
      });
    }, 2000);
  }

  function unsubscribe() {
    if (!subscriber) return Promise.resolve();
    try {
      subscriber.off('*');
      return subscriber.unsubscribe().catch(function () { return; });
    } catch (e) {
      return Promise.resolve();
    } finally {
      subscriber = null;
    }
  }

  // Override the UI's retry hook so the bridge button works
  NexBell.onVideoRetry = function () {
    log('Video retry requested by user');
    retryCount = 0;
    setVideoState('connecting', 'Reconnecting to camera…');
    unsubscribe().then(function () {
      subscribe();
    });
  };

  // ═══════════════════════════════════════════════════════════════════
  //  AI — Backend detection polling
  // ═══════════════════════════════════════════════════════════════════

  function updateAiStatus(detection) {
    if (!detection || detection.status === 'ai_not_configured' || detection.status === 'ai_request_failed') {
      NexBell.setState({ ai: 'unavailable' });
      log('AI unavailable: ' + ((detection && detection.explanation) || (detection && detection.status) || 'empty response'));
      return;
    }
    if (detection.status === 'capture_failed') {
      NexBell.setState({ ai: 'unavailable' });
      log('Camera capture failed: ' + (detection.explanation || 'unknown reason'));
      return;
    }
    NexBell.setState({ ai: 'ok' });
    var isHuman = detection.classification === 'HUMAN';
    var notify = isHuman && detection.should_notify === true;
    log('AI result: classification=' + detection.classification + ', confidence=' + detection.confidence + ', notify=' + notify);
    if (notify && !personVisitActive) {
      personVisitActive = true;
      var now = new Date();
      var timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      NexBell.doorbell({ time: timeStr, sample: false });
      log('Human detected: ' + (detection.explanation || 'person detected'));
    } else if (!isHuman) {
      noPersonResults++;
      if (noPersonResults >= 2) personVisitActive = false;
    } else {
      noPersonResults = 0;
    }
  }

  function apiFetch(path, method, body) {
    if (!API_BASE) return Promise.reject(new Error('API_BASE_URL_NOT_SET — configure apiBaseUrl in nexbell-config.js'));
    if (!API_TOKEN) return Promise.reject(new Error('API_TOKEN_NOT_SET — configure apiToken in nexbell-config.js'));
    var options = { method: method || 'GET', cache: 'no-store', headers: API_HEADERS };
    if (body !== undefined) options.body = JSON.stringify(body);
    return fetch(API_BASE + '/' + String(path).replace(/^\/+/, ''), options)
      .then(function (res) {
        var ct = res.headers.get('content-type') || '';
        if (ct.indexOf('text/html') !== -1) throw new Error('BACKEND_NOT_DEPLOYED — got HTML instead of JSON');
        if (!res.ok) return res.text().then(function (t) { throw new Error('HTTP ' + res.status + ': ' + t.slice(0, 240)); });
        return res.json();
      });
  }

  function poll() {
    apiFetch('api/analyze', 'POST', {})
      .then(function (data) {
        consecutiveErrors = 0;
        updateAiStatus(data);
      })
      .catch(function (err) {
        consecutiveErrors++;
        log('Detection poll failed (' + consecutiveErrors + '/' + MAX_ERRORS + '): ' + err.message);
        if (consecutiveErrors >= MAX_ERRORS) {
          NexBell.setState({ ai: 'unavailable' });
          log('AI unavailable after ' + MAX_ERRORS + ' errors — ' + err.message);
        }
      });
  }

  function startAiPolling() {
    log('AI polling active — ' + API_BASE + '/api/analyze every ' + (POLL_INTERVAL / 1000) + 's');
    // Check backend health first
    apiFetch('health').then(function (h) {
      log('Backend health: ' + (h.status || 'unknown') + ', service=' + (h.service || ''));
    }).catch(function (e) {
      log('Backend health check failed: ' + e.message);
    });
    poll();
    timer = setInterval(poll, POLL_INTERVAL);
  }

  // ═══════════════════════════════════════════════════════════════════
  //  DIAGNOSTICS — Override runChecks to use the Supabase backend
  // ═══════════════════════════════════════════════════════════════════

  function overrideRunChecks() {
    if (typeof window.runChecks !== 'function') {
      setTimeout(overrideRunChecks, 500);
      return;
    }

    var st = function (id, txt, ok) {
      var e = document.getElementById(id);
      if (!e) return;
      e.textContent = txt;
      e.className = 'pill ' + (ok ? 'yes' : 'no');
    };

    window.runChecks = function () {
      st('c-net', navigator.onLine ? 'Connected' : 'No connection', navigator.onLine);
      try {
        localStorage.setItem('nb_chk', '1');
        localStorage.removeItem('nb_chk');
        st('c-st', 'Working', true);
      } catch (e) {
        st('c-st', 'Blocked', false);
      }
      var p = window.NBDiag ? NBDiag.player() : 'idle';
      st('c-pl', {
        loaded: 'WebRTC connected',
        blocked: 'Blocked',
        problem: 'Playback error',
        loading: 'Connecting',
        idle: 'Not opened yet',
      }[p] || 'Unknown', p === 'loaded');
      st('c-cam', 'Checking…', false);
      st('c-bk', 'Checking…', false);

      // Camera status via edge function
      apiFetch('api/status').then(function (s) {
        if (s.stream && s.stream.connected) st('c-cam', 'Live on Red5', true);
        else st('c-cam', 'Stream offline', false);
      }).catch(function (e) { st('c-cam', 'Check failed', false); log('Camera status check: ' + e.message); });

      // Backend health via edge function
      apiFetch('health').then(function (j) {
        if (j && j.status === 'ok') {
          st('c-bk', 'Responding', true);
        } else {
          st('c-bk', 'Not connected', false);
        }
      }).catch(function () {
        st('c-bk', 'Not connected', false);
      });
    };
    log('Diagnostics runChecks() overridden to use NexBell FastAPI backend');
  }

  // ═══════════════════════════════════════════════════════════════════
  //  STARTUP
  // ═══════════════════════════════════════════════════════════════════

  function start() {
    log('Bridge active — initializing video and AI detection');
    initVideoElement();
    startAiPolling();
    overrideRunChecks();
  }

  if (document.readyState === 'complete') {
    start();
  } else {
    window.addEventListener('load', start);
  }
})();
