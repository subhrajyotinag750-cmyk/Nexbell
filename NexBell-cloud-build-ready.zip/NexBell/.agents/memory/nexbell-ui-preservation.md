---
name: NexBell UI preservation
description: The user's permanent visual and interaction constraints for NexBell.
---

For NexBell, preserve the approved interface. Do not alter `NexBell.html`, its CSS, layout, visual assets, fonts, typography, animations, icons, navigation, screens, or existing interactions. Ask before making any visible UI change.

**Why:** the user explicitly set a permanent UI lock.

**How to apply:** keep Phase 1 and later work backend-only unless the user approves a visible UI change.
