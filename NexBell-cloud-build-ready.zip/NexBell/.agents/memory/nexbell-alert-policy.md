---
name: NexBell alert policy
description: User-defined visitor detection, deduplication, and escalation rules.
---

Create visitor alerts for confirmed people in the configured entrance zone, using confidence thresholds and deduplication. Group multiple people from one visit into one event; prioritize approach only when movement is reliably determined. Vehicles, animals, and general motion do not trigger visitor alerts. Uncertain detections do not trigger an incoming-call escalation. Notify the primary phone first, escalate to Backup 1 after 60 seconds and Backup 2 after another 60 seconds, and cancel pending escalation when an authorized member acknowledges. Deliver alerts in-app and in the background.

**Why:** the user explicitly specified these alert and escalation behaviors.

**How to apply:** enforce these rules in backend event creation and routing; do not broaden alert-trigger categories without the user's instruction.
